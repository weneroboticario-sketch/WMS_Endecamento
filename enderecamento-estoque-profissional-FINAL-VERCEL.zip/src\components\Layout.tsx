import {
  Barcode,
  Boxes,
  FileDown,
  FileUp,
  Gauge,
  History,
  LogOut,
  MapPinned,
  PackageSearch,
  ScanLine,
  Settings,
  Users
} from "lucide-react";
import type { ReactNode } from "react";
import type { User } from "../types";

export type PageKey =
  | "dashboard"
  | "address"
  | "sku"
  | "shelf"
  | "labels"
  | "export"
  | "import"
  | "history"
  | "users"
  | "settings";

const menu = [
  { key: "dashboard", label: "Dashboard", icon: Gauge },
  { key: "address", label: "Endereçar Produto", icon: ScanLine },
  { key: "sku", label: "Consultar SKU", icon: PackageSearch },
  { key: "shelf", label: "Consultar Prateleira", icon: MapPinned },
  { key: "labels", label: "Gerar Etiquetas", icon: Barcode },
  { key: "export", label: "Exportar Excel", icon: FileDown },
  { key: "import", label: "Importar Excel", icon: FileUp },
  { key: "history", label: "Histórico", icon: History },
  { key: "users", label: "Usuários", icon: Users },
  { key: "settings", label: "Configurações", icon: Settings }
] as const;

export function Layout({
  activePage,
  onNavigate,
  children
  ,
  user,
  onLogout
}: {
  activePage: PageKey;
  onNavigate: (page: PageKey) => void;
  children: ReactNode;
  user: User;
  onLogout: () => void;
}) {
  return (
    <div className="shell">
      <aside className="sidebar">
        <div className="brand">
          <Boxes size={30} />
          <div>
            <strong>Estoque Pro</strong>
            <span>Endereçamento</span>
          </div>
        </div>

        <nav className="nav">
          {menu.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                className={activePage === item.key ? "nav-item active" : "nav-item"}
                onClick={() => onNavigate(item.key)}
                type="button"
              >
                <Icon size={18} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div>
            <strong>{user.nome}</strong>
            <span>{user.perfil}</span>
          </div>
          <button className="secondary" onClick={onLogout} type="button">
            <LogOut size={18} />
            Sair
          </button>
        </header>
        <div className="content">{children}</div>
      </main>
    </div>
  );
}
