import { Barcode, FileDown, MapPinned, PackageCheck, PackageSearch, ScanLine, Users } from "lucide-react";
import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { formatDateTime } from "../lib/address";
import type { Addressing } from "../types";
import type { PageKey } from "../components/Layout";

type DashboardData = {
  totals: {
    produtosEnderecados: number;
    vinculosSkuEndereco: number;
    localizacoesCriadas: number;
    skusDistintos: number;
  };
  byArea: Array<{ codigo: number; nome: string; total: number }>;
  latest: Addressing[];
  topShelves: Array<{ codigo_endereco: string; total: number }>;
  byUser: Array<{ nome: string; total: number }>;
};

const shortcuts: Array<{ page: PageKey; label: string; icon: typeof ScanLine }> = [
  { page: "address", label: "Endereçar Produto", icon: ScanLine },
  { page: "sku", label: "Consultar SKU", icon: PackageSearch },
  { page: "shelf", label: "Consultar Prateleira", icon: MapPinned },
  { page: "labels", label: "Gerar Etiquetas", icon: Barcode },
  { page: "export", label: "Exportar Excel", icon: FileDown }
];

export function Dashboard({ onNavigate }: { onNavigate: (page: PageKey) => void }) {
  const [data, setData] = useState<DashboardData | null>(null);

  useEffect(() => {
    api.dashboard().then(setData);
  }, []);

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Operação logística</span>
          <h1>Dashboard</h1>
        </div>
        <button className="primary" onClick={() => onNavigate("address")} type="button">
          <ScanLine size={18} />
          Endereçar Produto
        </button>
      </div>

      <div className="metric-grid">
        <Metric label="Vínculos SKU + endereço" value={data?.totals.vinculosSkuEndereco ?? 0} />
        <Metric label="Localizações criadas" value={data?.totals.localizacoesCriadas ?? 0} />
        <Metric label="SKUs distintos" value={data?.totals.skusDistintos ?? 0} />
      </div>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-title">
            <PackageCheck size={18} />
            <h2>SKUs por Área Linha Separação</h2>
          </div>
          <div className="area-bars">
            {(data?.byArea || []).map((area) => (
              <div className="area-bar" key={area.codigo}>
                <span>{area.codigo} - {area.nome}</span>
                <strong>{area.total}</strong>
              </div>
            ))}
            {!data?.byArea.length && <p className="muted">Nenhum endereçamento registrado.</p>}
          </div>
        </section>

        <section className="panel">
          <div className="panel-title">
            <ScanLine size={18} />
            <h2>Acesso rápido</h2>
          </div>
          <div className="shortcut-grid">
            {shortcuts.map((shortcut) => {
              const Icon = shortcut.icon;
              return (
                <button key={shortcut.page} className="shortcut" onClick={() => onNavigate(shortcut.page)}>
                  <Icon size={20} />
                  <span>{shortcut.label}</span>
                </button>
              );
            })}
          </div>
        </section>
      </div>

      <div className="dashboard-grid">
        <section className="panel">
          <div className="panel-title">
            <MapPinned size={18} />
            <h2>Prateleiras com mais SKUs</h2>
          </div>
          <div className="area-bars">
            {(data?.topShelves || []).map((shelf) => (
              <div className="area-bar" key={shelf.codigo_endereco}>
                <span>{shelf.codigo_endereco}</span>
                <strong>{shelf.total}</strong>
              </div>
            ))}
          </div>
        </section>

        <section className="panel">
          <div className="panel-title">
            <Users size={18} />
            <h2>Endereçamentos por usuário</h2>
          </div>
          <div className="area-bars">
            {(data?.byUser || []).map((user) => (
              <div className="area-bar" key={user.nome}>
                <span>{user.nome}</span>
                <strong>{user.total}</strong>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="panel-title">
          <MapPinned size={18} />
          <h2>Últimos endereçamentos feitos</h2>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Código Material</th>
                <th>Prateleira</th>
                <th>Área Linha Separação</th>
                <th>Usuário</th>
                <th>Data e hora</th>
              </tr>
            </thead>
            <tbody>
              {(data?.latest || []).map((row) => (
                <tr key={row.id}>
                  <td>{row.sku}</td>
                  <td>{row.codigo_endereco}</td>
                  <td>{row.area_linha_separacao_nome}</td>
                  <td>{row.usuario_nome || "Sem usuário"}</td>
                  <td>{formatDateTime(row.criado_em)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
