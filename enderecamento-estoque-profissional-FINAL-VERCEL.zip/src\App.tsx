import { useState } from "react";
import { Layout, type PageKey } from "./components/Layout";
import { AddressProduct } from "./pages/AddressProduct";
import { ConsultShelf } from "./pages/ConsultShelf";
import { ConsultSku } from "./pages/ConsultSku";
import { Dashboard } from "./pages/Dashboard";
import { ExportExcel } from "./pages/ExportExcel";
import { ImportExcel } from "./pages/ImportExcel";
import { Labels } from "./pages/Labels";
import { LoginPage } from "./pages/LoginPage";
import { SettingsPage } from "./pages/SettingsPage";
import { HistoryPage } from "./pages/HistoryPage";
import { UsersPage } from "./pages/UsersPage";
import { clearAuth, loadAuth, loadSettings, saveAuth } from "./lib/storage";
import type { Settings, User } from "./types";

export default function App() {
  const [page, setPage] = useState<PageKey>("dashboard");
  const [settings, setSettings] = useState<Settings>(() => loadSettings());
  const [auth, setAuth] = useState<{ token: string; user: User } | null>(() => loadAuth());

  if (!auth) {
    return (
      <LoginPage
        onLogin={(nextAuth) => {
          saveAuth(nextAuth);
          setAuth(nextAuth);
        }}
      />
    );
  }

  return (
    <Layout
      activePage={page}
      onNavigate={setPage}
      user={auth.user}
      onLogout={() => {
        clearAuth();
        setAuth(null);
        setPage("dashboard");
      }}
    >
      {page === "dashboard" && <Dashboard onNavigate={setPage} />}
      {page === "address" && <AddressProduct settings={settings} />}
      {page === "sku" && <ConsultSku />}
      {page === "shelf" && <ConsultShelf />}
      {page === "labels" && <Labels />}
      {page === "export" && <ExportExcel />}
      {page === "import" && <ImportExcel />}
      {page === "history" && <HistoryPage />}
      {page === "users" && <UsersPage />}
      {page === "settings" && <SettingsPage settings={settings} onChange={setSettings} />}
    </Layout>
  );
}
