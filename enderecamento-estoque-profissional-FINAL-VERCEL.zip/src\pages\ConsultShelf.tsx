import { MapPinned, Package } from "lucide-react";
import { FormEvent, useState } from "react";
import { api } from "../lib/api";
import type { Addressing, ParsedShelf } from "../types";

export function ConsultShelf() {
  const [code, setCode] = useState("");
  const [address, setAddress] = useState<ParsedShelf | null>(null);
  const [skus, setSkus] = useState<Addressing[]>([]);
  const [message, setMessage] = useState("");

  async function search(event?: FormEvent) {
    event?.preventDefault();
    if (!code.trim()) {
      return;
    }

    try {
      const result = await api.searchShelf(code.trim());
      setAddress(result.address);
      setSkus(result.skus);
      setMessage(`${result.totalSkus} SKU(s) nesta prateleira.`);
    } catch (error) {
      setAddress(null);
      setSkus([]);
      setMessage(error instanceof Error ? error.message : "Código de prateleira inválido.");
    }
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Consulta por endereço</span>
          <h1>Consultar Prateleira</h1>
        </div>
      </div>

      <form className="search-row" onSubmit={search}>
        <label className="field">
          <span>Código da Prateleira</span>
          <input
            value={code}
            onChange={(event) => setCode(event.target.value.toUpperCase())}
            placeholder="R01-RK01-L01-A"
            autoComplete="off"
          />
        </label>
        <button className="primary" type="submit">
          <MapPinned size={18} />
          Consultar
        </button>
      </form>

      {message && <div className="system-message ok">{message}</div>}

      {address && (
        <div className="address-strip">
          <span>{address.rua}</span>
          <span>Rack {address.rack}</span>
          <span>Linha {address.linha}</span>
          <span>Letra {address.letra}</span>
        </div>
      )}

      <section className="panel">
        <div className="panel-title">
          <Package size={18} />
          <h2>SKUs alocados</h2>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Código Material</th>
                <th>Área Linha Separação</th>
                <th>Rua</th>
                <th>Rack</th>
                <th>Linha</th>
                <th>Letra</th>
              </tr>
            </thead>
            <tbody>
              {skus.map((row) => (
                <tr key={row.id}>
                  <td>{row.sku}</td>
                  <td>{row.area_linha_separacao_nome}</td>
                  <td>{row.rua}</td>
                  <td>{row.rack}</td>
                  <td>{row.linha}</td>
                  <td>{row.letra}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
