import { Save } from "lucide-react";
import { FormEvent, useState } from "react";
import { saveSettings } from "../lib/storage";
import type { Settings } from "../types";

export function SettingsPage({
  settings,
  onChange
}: {
  settings: Settings;
  onChange: (settings: Settings) => void;
}) {
  const [draft, setDraft] = useState(settings);
  const [message, setMessage] = useState("");

  function save(event: FormEvent) {
    event.preventDefault();
    saveSettings(draft);
    onChange(draft);
    setMessage("Configurações salvas.");
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Padrão técnico</span>
          <h1>Configurações</h1>
        </div>
      </div>

      <form className="panel settings-grid" onSubmit={save}>
        <label className="field">
          <span>Prefixo da Rua</span>
          <input value={draft.ruaPrefix} onChange={(event) => setDraft({ ...draft, ruaPrefix: event.target.value.toUpperCase() })} />
        </label>
        <label className="field">
          <span>Prefixo do Rack</span>
          <input value={draft.rackPrefix} onChange={(event) => setDraft({ ...draft, rackPrefix: event.target.value.toUpperCase() })} />
        </label>
        <label className="field">
          <span>Prefixo da Linha</span>
          <input value={draft.linhaPrefix} onChange={(event) => setDraft({ ...draft, linhaPrefix: event.target.value.toUpperCase() })} />
        </label>
        <label className="field">
          <span>Dígitos de Rua, Rack e Linha</span>
          <input type="number" min="1" max="4" value={draft.digits} onChange={(event) => setDraft({ ...draft, digits: Number(event.target.value) })} />
        </label>
        <label className="field wide">
          <span>Padrão de código da prateleira</span>
          <input value={draft.shelfPattern} onChange={(event) => setDraft({ ...draft, shelfPattern: event.target.value.toUpperCase() })} />
        </label>
        <label className="toggle-row wide">
          <input
            checked={draft.autoCreateAddress}
            onChange={(event) => setDraft({ ...draft, autoCreateAddress: event.target.checked })}
            type="checkbox"
          />
          <span>Cadastrar endereço automaticamente ao bipar</span>
        </label>
        <label className="toggle-row wide">
          <input
            checked={draft.autoSave}
            onChange={(event) => setDraft({ ...draft, autoSave: event.target.checked })}
            type="checkbox"
          />
          <span>Gravar automaticamente após bipar a prateleira</span>
        </label>
        <label className="toggle-row wide">
          <input
            checked={draft.enableCamera}
            onChange={(event) => setDraft({ ...draft, enableCamera: event.target.checked })}
            type="checkbox"
          />
          <span>Habilitar leitura por câmera quando o navegador suportar</span>
        </label>
        <button className="primary" type="submit">
          <Save size={18} />
          Salvar Configurações
        </button>
      </form>

      {message && <div className="system-message ok">{message}</div>}
    </section>
  );
}
