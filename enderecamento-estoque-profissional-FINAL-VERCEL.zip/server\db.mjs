import { mkdirSync } from "node:fs";
import crypto from "node:crypto";
import { dirname, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
import { fileURLToPath } from "node:url";
import { AREAS, buildShelfCode, parseShelfCode } from "./addressing.mjs";

const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const dbPath = resolve(rootDir, "data", "enderecamento.sqlite");
mkdirSync(dirname(dbPath), { recursive: true });

export const db = new DatabaseSync(dbPath);
db.exec("PRAGMA journal_mode = WAL;");
db.exec("PRAGMA foreign_keys = ON;");

export function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      senha_hash TEXT NOT NULL,
      perfil TEXT NOT NULL CHECK (perfil IN ('Administrador', 'Supervisor', 'Operador')),
      ativo INTEGER NOT NULL DEFAULT 1,
      criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS enderecos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rua TEXT NOT NULL,
      rack INTEGER NOT NULL,
      linha INTEGER NOT NULL,
      letra TEXT NOT NULL,
      codigo_endereco TEXT NOT NULL UNIQUE,
      criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS localizacoes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      rua TEXT NOT NULL,
      rack INTEGER NOT NULL,
      linha INTEGER NOT NULL,
      letra TEXT NOT NULL,
      codigo_endereco TEXT NOT NULL UNIQUE,
      criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS enderecamentos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sku TEXT NOT NULL,
      rua TEXT NOT NULL,
      rack INTEGER NOT NULL,
      linha INTEGER NOT NULL,
      letra TEXT NOT NULL,
      codigo_endereco TEXT NOT NULL,
      area_linha_separacao_codigo INTEGER NOT NULL,
      area_linha_separacao_nome TEXT NOT NULL,
      conferencia_obrigatoria INTEGER NOT NULL DEFAULT 0,
      criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(sku, codigo_endereco)
    );

    CREATE TABLE IF NOT EXISTS historico (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER,
      acao TEXT NOT NULL,
      sku TEXT,
      codigo_endereco TEXT,
      detalhes TEXT,
      criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
    );

    CREATE TABLE IF NOT EXISTS configuracoes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      chave TEXT NOT NULL UNIQUE,
      valor TEXT NOT NULL,
      atualizado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_enderecamentos_sku ON enderecamentos(sku);
    CREATE INDEX IF NOT EXISTS idx_enderecamentos_codigo ON enderecamentos(codigo_endereco);
    CREATE INDEX IF NOT EXISTS idx_enderecamentos_area ON enderecamentos(area_linha_separacao_codigo);
    CREATE INDEX IF NOT EXISTS idx_historico_criado_em ON historico(criado_em);
  `);

  migrateColumns();
  db.exec(`
    INSERT OR IGNORE INTO localizacoes (id, rua, rack, linha, letra, codigo_endereco, criado_em, atualizado_em)
    SELECT id, rua, rack, linha, letra, codigo_endereco, criado_em, atualizado_em FROM enderecos;
  `);
  seedUsers();
  seedData();
}

function migrateColumns() {
  addColumn("enderecamentos", "localizacao_id", "INTEGER");
  addColumn("enderecamentos", "usuario_id", "INTEGER");
}

function addColumn(table, column, definition) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all().map((item) => item.name);
  if (!columns.includes(column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition};`);
  }
}

export function ensureAddress(parsed) {
  const existing = db
    .prepare("SELECT * FROM localizacoes WHERE codigo_endereco = ?")
    .get(parsed.codigo_endereco);

  if (existing) {
    return existing;
  }

  db.prepare(`
    INSERT OR IGNORE INTO localizacoes (rua, rack, linha, letra, codigo_endereco)
    VALUES (?, ?, ?, ?, ?)
  `).run(parsed.rua, parsed.rack, parsed.linha, parsed.letra, parsed.codigo_endereco);

  return db
    .prepare("SELECT * FROM localizacoes WHERE codigo_endereco = ?")
    .get(parsed.codigo_endereco);
}

export function addAddressing({ sku, shelfCode, areaCode, createAddress = true, usuarioId = null }) {
  const cleanSku = String(sku || "").trim();
  if (!cleanSku) {
    return { ok: false, status: 400, message: "SKU obrigatório." };
  }

  const parsed = parseShelfCode(shelfCode);
  if (!parsed) {
    return { ok: false, status: 400, message: "Código de prateleira inválido." };
  }

  const area = AREAS.find((item) => item.codigo === Number(areaCode));
  if (!area) {
    return { ok: false, status: 400, message: "Área Linha Separação obrigatória." };
  }

  const existingAddress = db
    .prepare("SELECT * FROM localizacoes WHERE codigo_endereco = ?")
    .get(parsed.codigo_endereco);

  if (!existingAddress && !createAddress) {
    return {
      ok: false,
      status: 404,
      message: "Endereço não cadastrado.",
      parsedAddress: parsed
    };
  }

  const address = ensureAddress(parsed);

  try {
    db.prepare(`
      INSERT INTO enderecamentos (
        sku, localizacao_id, rua, rack, linha, letra, codigo_endereco,
        area_linha_separacao_codigo, area_linha_separacao_nome,
        conferencia_obrigatoria, usuario_id
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
    `).run(
      cleanSku,
      address.id,
      parsed.rua,
      parsed.rack,
      parsed.linha,
      parsed.letra,
      parsed.codigo_endereco,
      area.codigo,
      area.nome,
      usuarioId
    );
  } catch (error) {
    if (String(error.message).includes("UNIQUE")) {
      return {
        ok: false,
        status: 409,
        message: "Este SKU já está cadastrado neste endereço."
      };
    }
    throw error;
  }

  const record = db
    .prepare(`
      SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      WHERE e.id = last_insert_rowid()
    `)
    .get();

  logAction({
    usuarioId,
    acao: "SKU endereçado",
    sku: cleanSku,
    codigoEndereco: parsed.codigo_endereco,
    detalhes: `Área ${area.codigo} - ${area.nome}`
  });

  return {
    ok: true,
    status: 201,
    message: "SKU endereçado com sucesso.",
    record
  };
}

export function logAction({ usuarioId = null, acao, sku = null, codigoEndereco = null, detalhes = null }) {
  db.prepare(`
    INSERT INTO historico (usuario_id, acao, sku, codigo_endereco, detalhes)
    VALUES (?, ?, ?, ?, ?)
  `).run(usuarioId, acao, sku, codigoEndereco, detalhes);
}

function seedUsers() {
  const users = [
    ["Administrador", "admin@estoque.local", "admin123", "Administrador"],
    ["Supervisor", "supervisor@estoque.local", "supervisor123", "Supervisor"],
    ["Operador", "operador@estoque.local", "operador123", "Operador"]
  ];

  for (const [nome, email, senha, perfil] of users) {
    db.prepare(`
      INSERT OR IGNORE INTO usuarios (nome, email, senha_hash, perfil, ativo)
      VALUES (?, ?, ?, ?, 1)
    `).run(nome, email, hashPasswordForSeed(senha), perfil);
  }
}

function hashPasswordForSeed(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.pbkdf2Sync(String(password), salt, 120000, 32, "sha256").toString("hex");
  return `${salt}:${hash}`;
}

function seedData() {
  const samples = [
    ["89261", "R01-RK01-L01-A", 1],
    ["48139", "R01-RK01-L01-B", 2],
    ["84915", "R02-RK01-L02-A", 3],
    ["87842", "R03-RK02-L01-C", 4],
    ["90249", "R04-RK01-L03-A", 5]
  ];

  const admin = db.prepare("SELECT id FROM usuarios WHERE email = ?").get("admin@estoque.local");

  for (const [sku, code, area] of samples) {
    addAddressing({ sku, shelfCode: code, areaCode: area, createAddress: true, usuarioId: admin?.id || null });
  }

  for (let rua = 1; rua <= 3; rua += 1) {
    for (let rack = 1; rack <= 2; rack += 1) {
      for (let linha = 1; linha <= 3; linha += 1) {
        for (const letra of ["A", "B", "C"]) {
          ensureAddress(parseShelfCode(buildShelfCode({ ruaNumero: rua, rack, linha, letra })));
        }
      }
    }
  }
}
