import { CheckCircle2, MapPinned, RotateCcw, Save, ScanBarcode, Trash2 } from "lucide-react";
import { ChangeEvent, FormEvent, KeyboardEvent, useEffect, useRef, useState } from "react";
import { api } from "../lib/api";
import { formatDateTime, parseShelfCode } from "../lib/address";
import type { Addressing, Area, Settings } from "../types";

export function AddressProduct({ settings }: { settings: Settings }) {
  const [areas, setAreas] = useState<Area[]>([]);
  const [sku, setSku] = useState("");
  const [shelfCode, setShelfCode] = useState("");
  const [areaCode, setAreaCode] = useState("1");
  const [message, setMessage] = useState("Bipe o Produto.");
  const [status, setStatus] = useState<"idle" | "ok" | "warn" | "error">("idle");
  const [parsedAddress, setParsedAddress] = useState<ReturnType<typeof parseShelfCode>>(null);
  const [skuLocations, setSkuLocations] = useState<Addressing[]>([]);
  const [loading, setLoading] = useState(false);
  const skuRef = useRef<HTMLInputElement | null>(null);
  const shelfRef = useRef<HTMLInputElement | null>(null);
  const cameraRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    api.areas().then(setAreas);
    skuRef.current?.focus();
  }, []);

  async function onSkuKey(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Enter" && sku.trim()) {
      event.preventDefault();
      await consultSku();
    }
  }

  async function onShelfKey(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key !== "Enter") {
      return;
    }

    event.preventDefault();
    const valid = await validateShelf();
    if (valid && settings.autoSave) {
      await saveAddressing();
    }
  }

  async function consultSku(nextSku = sku) {
    const cleanSku = nextSku.trim();
    if (!cleanSku) {
      setStatus("error");
      setMessage("SKU obrigatório.");
      return;
    }

    setLoading(true);
    try {
      const rows = await api.searchSku(cleanSku);
      setSkuLocations(rows);
      if (rows.length) {
        setStatus("ok");
        setMessage("Produto já possui localização.");
        skuRef.current?.select();
      } else {
        setStatus("warn");
        setMessage("Produto sem localização cadastrada. Bipe a prateleira para endereçar.");
        shelfRef.current?.focus();
      }
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Erro ao consultar SKU.");
    } finally {
      setLoading(false);
    }
  }

  async function validateShelf() {
    const parsed = parseShelfCode(shelfCode);
    setParsedAddress(parsed);

    if (!parsed) {
      setStatus("error");
      setMessage("Código de prateleira inválido. Use o padrão R01-RK01-L01-A.");
      return false;
    }

    try {
      const result = await api.checkAddress(shelfCode);
      setStatus(result.exists ? "ok" : "warn");
      setMessage(result.exists ? "Endereço identificado." : "Endereço identificado. Será cadastrado automaticamente ao salvar.");
      return true;
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Código de prateleira inválido.");
      return false;
    }
  }

  async function saveAddressing() {
    const validShelf = await validateShelf();
    if (!validShelf) {
      return;
    }

    try {
      const result = await api.createAddressing({
        sku,
        shelfCode,
        areaCode: Number(areaCode),
        createAddress: settings.autoCreateAddress
      });
      setStatus("ok");
      setMessage(`${result.message || "SKU endereçado com sucesso."} Pronto para o próximo produto.`);
      clearForm();
    } catch (error) {
      setStatus("error");
      setMessage(error instanceof Error ? error.message : "Erro ao salvar endereçamento.");
    }
  }

  async function save(event: FormEvent) {
    event.preventDefault();
    await saveAddressing();
  }

  function clearForm() {
    setSku("");
    setShelfCode("");
    setParsedAddress(null);
    setSkuLocations([]);
    setTimeout(() => skuRef.current?.focus(), 20);
  }

  async function remove(row: Addressing) {
    if (!confirm(`Remover o vínculo do SKU ${row.sku} em ${row.codigo_endereco}?`)) {
      return;
    }

    await api.deleteAddressing(row.id);
    setSkuLocations((current) => current.filter((item) => item.id !== row.id));
    setStatus("ok");
    setMessage("Endereço removido.");
  }

  async function readCameraImage(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) {
      return;
    }

    const BarcodeDetectorCtor = (window as unknown as { BarcodeDetector?: new (options?: unknown) => { detect: (image: ImageBitmap) => Promise<Array<{ rawValue: string }>> } }).BarcodeDetector;
    if (!BarcodeDetectorCtor) {
      setStatus("error");
      setMessage("Leitura por câmera não suportada neste navegador. Use o leitor Bluetooth/USB ou digite manualmente.");
      return;
    }

    try {
      const image = await createImageBitmap(file);
      const detector = new BarcodeDetectorCtor({ formats: ["code_128", "ean_13", "code_39", "qr_code"] });
      const codes = await detector.detect(image);
      if (!codes.length) {
        setStatus("warn");
        setMessage("Nenhum código identificado pela câmera.");
        return;
      }
      setSku(codes[0].rawValue);
      setStatus("ok");
      setMessage("Produto bipado com sucesso.");
      setTimeout(() => consultSku(codes[0].rawValue), 20);
    } catch {
      setStatus("error");
      setMessage("Não foi possível ler o código pela câmera.");
    }
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Fluxo principal</span>
          <h1>Bipagem / Endereçamento</h1>
        </div>
      </div>

      <form className="scan-form" onSubmit={save}>
        <label className="field jumbo">
          <span>Código Material / SKU</span>
          <div className="input-icon">
            <ScanBarcode size={24} />
            <input
              ref={skuRef}
              value={sku}
              onChange={(event) => setSku(event.target.value)}
              onKeyDown={onSkuKey}
              placeholder="Bipe o Produto"
              autoComplete="off"
            />
          </div>
        </label>

        {skuLocations.length > 0 && (
          <section className="located-panel">
            <div className="panel-title">
              <CheckCircle2 size={18} />
              <h2>Localização encontrada para guardar o produto</h2>
            </div>
            <div className="location-list">
              {skuLocations.map((row) => (
                <div className="location-card" key={row.id}>
                  <div>
                    <strong>{row.codigo_endereco}</strong>
                    <span>
                      {row.rua} / Rack {row.rack} / Linha {row.linha} / Letra {row.letra}
                    </span>
                    <small>
                      Área: {row.area_linha_separacao_nome} · Atualizado: {formatDateTime(row.atualizado_em)} · Usuário:{" "}
                      {row.usuario_nome || "Sem usuário"}
                    </small>
                  </div>
                  <button className="icon-button danger" onClick={() => remove(row)} type="button" title="Remover vínculo">
                    <Trash2 size={17} />
                  </button>
                </div>
              ))}
            </div>
          </section>
        )}

        <label className="field jumbo">
          <span>Código da Prateleira</span>
          <div className="input-icon">
            <MapPinned size={24} />
            <input
              ref={shelfRef}
              value={shelfCode}
              onChange={(event) => setShelfCode(event.target.value.toUpperCase())}
              onKeyDown={onShelfKey}
              onBlur={() => shelfCode && validateShelf()}
              placeholder="R01-RK01-L01-A"
              autoComplete="off"
            />
          </div>
        </label>

        <label className="field">
          <span>Área Linha Separação</span>
          <select value={areaCode} onChange={(event) => setAreaCode(event.target.value)}>
            {areas.map((area) => (
              <option key={area.codigo} value={area.codigo}>
                {area.codigo} - {area.nome}
              </option>
            ))}
          </select>
        </label>

        {parsedAddress && (
          <div className="address-preview">
            <CheckCircle2 size={20} />
            <span>{parsedAddress.rua}</span>
            <span>Rack {parsedAddress.rack}</span>
            <span>Linha {parsedAddress.linha}</span>
            <span>Letra {parsedAddress.letra}</span>
          </div>
        )}

        <div className={`system-message ${status}`}>{loading ? "Consultando SKU..." : message}</div>

        <div className="button-row">
          {settings.enableCamera && (
            <>
              <input
                ref={cameraRef}
                accept="image/*"
                capture="environment"
                className="hidden-input"
                onChange={readCameraImage}
                type="file"
              />
              <button className="secondary large-action" onClick={() => cameraRef.current?.click()} type="button">
                <ScanBarcode size={20} />
                Ler câmera
              </button>
            </>
          )}
          <button className="primary large-action" type="submit">
            <Save size={20} />
            Salvar manualmente
          </button>
          <button className="secondary large-action" onClick={clearForm} type="button">
            <RotateCcw size={20} />
            Limpar
          </button>
        </div>
      </form>
    </section>
  );
}
