export const AREAS = [
  { codigo: 1, nome: "Alto Giro" },
  { codigo: 2, nome: "Médio Giro" },
  { codigo: 3, nome: "Área RF" },
  { codigo: 4, nome: "Baixo Giro" },
  { codigo: 5, nome: "Picking by Light" }
];

export function areaByCode(code) {
  return AREAS.find((area) => area.codigo === Number(code));
}

export function padNumber(value, digits = 2) {
  return String(Number(value)).padStart(digits, "0");
}

export function normalizeLetter(value) {
  return String(value || "").trim().toUpperCase();
}

export function buildShelfCode({ rack, linha, letra, ruaNumero }) {
  return `R${padNumber(ruaNumero)}-RK${padNumber(rack)}-L${padNumber(linha)}-${normalizeLetter(letra)}`;
}

export function parseShelfCode(rawCode) {
  const code = String(rawCode || "").trim().toUpperCase();
  const match = code.match(/^R(\d+)-RK(\d+)-L(\d+)-([A-Z]+)$/);

  if (!match) {
    return null;
  }

  const ruaNumero = Number(match[1]);
  const rack = Number(match[2]);
  const linha = Number(match[3]);
  const letra = match[4];

  return {
    rua: `Rua ${padNumber(ruaNumero)}`,
    ruaNumero,
    rack,
    linha,
    letra,
    codigo_endereco: buildShelfCode({ ruaNumero, rack, linha, letra })
  };
}
