import JsBarcode from "jsbarcode";
import { useEffect, useRef } from "react";

export function BarcodeLabel({ code }: { code: string }) {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current || !code) {
      return;
    }

    JsBarcode(svgRef.current, code, {
      format: "CODE128",
      width: 2,
      height: 52,
      margin: 8,
      displayValue: false
    });
  }, [code]);

  return (
    <div className="label-card">
      <svg ref={svgRef} aria-label={`Código de barras ${code}`} />
      <strong>{code}</strong>
    </div>
  );
}
