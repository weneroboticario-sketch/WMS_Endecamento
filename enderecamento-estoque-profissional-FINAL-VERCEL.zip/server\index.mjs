import cors from "cors";
import express from "express";
import { existsSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createToken, hashPassword, publicUser, readToken, verifyPassword } from "./auth.mjs";
import { AREAS, areaByCode, parseShelfCode } from "./addressing.mjs";
import { addAddressing, db, ensureAddress, initDb, logAction } from "./db.mjs";

initDb();

const app = express();
const port = Number(process.env.PORT || 3333);
const host = process.env.HOST || "0.0.0.0";
const rootDir = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const distDir = resolve(rootDir, "dist");

app.use(cors());
app.use(express.json({ limit: "10mb" }));
app.use((req, _res, next) => {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  req.user = token ? readToken(token) : null;
  next();
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.post("/api/auth/login", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = db.prepare("SELECT * FROM usuarios WHERE lower(email) = ? AND ativo = 1").get(email);

  if (!user || !verifyPassword(password, user.senha_hash)) {
    return res.status(401).json({ message: "Usuário ou senha inválidos." });
  }

  logAction({ usuarioId: user.id, acao: "Login realizado", detalhes: "Acesso ao sistema" });
  res.json({ token: createToken(user), user: publicUser(user) });
});

app.get("/api/auth/me", (req, res) => {
  if (!req.user) {
    return res.status(401).json({ message: "Sessão inválida." });
  }
  res.json(publicUser(req.user));
});

app.get("/api/areas", (_req, res) => {
  res.json(AREAS);
});

app.get("/api/dashboard", (_req, res) => {
  const totals = {
    produtosEnderecados: db.prepare("SELECT COUNT(*) AS total FROM enderecamentos").get().total,
    vinculosSkuEndereco: db.prepare("SELECT COUNT(*) AS total FROM enderecamentos").get().total,
    localizacoesCriadas: db.prepare("SELECT COUNT(*) AS total FROM localizacoes").get().total,
    skusDistintos: db.prepare("SELECT COUNT(DISTINCT sku) AS total FROM enderecamentos").get().total
  };

  const byArea = db
    .prepare(`
      SELECT area_linha_separacao_codigo AS codigo, area_linha_separacao_nome AS nome, COUNT(*) AS total
      FROM enderecamentos
      GROUP BY area_linha_separacao_codigo, area_linha_separacao_nome
      ORDER BY area_linha_separacao_codigo
    `)
    .all();

  const latest = db
    .prepare(`
      SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      ORDER BY e.criado_em DESC, e.id DESC
      LIMIT 10
    `)
    .all();

  const topShelves = db
    .prepare(`
      SELECT codigo_endereco, rua, rack, linha, letra, COUNT(*) AS total
      FROM enderecamentos
      GROUP BY codigo_endereco, rua, rack, linha, letra
      ORDER BY total DESC, codigo_endereco
      LIMIT 8
    `)
    .all();

  const byUser = db
    .prepare(`
      SELECT COALESCE(u.nome, 'Sem usuário') AS nome, COUNT(e.id) AS total
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      GROUP BY COALESCE(u.nome, 'Sem usuário')
      ORDER BY total DESC
      LIMIT 8
    `)
    .all();

  res.json({ totals, byArea, latest, topShelves, byUser });
});

app.get("/api/addresses/check/:code", (req, res) => {
  const parsed = parseShelfCode(req.params.code);
  if (!parsed) {
    return res.status(400).json({ message: "Código de prateleira inválido. Use o padrão R01-RK01-L01-A." });
  }

  const existing = db
    .prepare("SELECT * FROM localizacoes WHERE codigo_endereco = ?")
    .get(parsed.codigo_endereco);

  res.json({ exists: Boolean(existing), address: existing || parsed });
});

app.post("/api/addresses", (req, res) => {
  const parsed = parseShelfCode(req.body.shelfCode);
  if (!parsed) {
    return res.status(400).json({ message: "Código de prateleira inválido. Use o padrão R01-RK01-L01-A." });
  }

  const address = ensureAddress(parsed);
  res.status(201).json(address);
});

app.get("/api/addressings", (req, res) => {
  const where = [];
  const params = [];

  if (req.query.area) {
    where.push("e.area_linha_separacao_codigo = ?");
    params.push(Number(req.query.area));
  }
  if (req.query.rua) {
    where.push("e.rua = ?");
    params.push(String(req.query.rua));
  }
  if (req.query.rack) {
    where.push("e.rack = ?");
    params.push(Number(req.query.rack));
  }
  if (req.query.from) {
    where.push("e.criado_em >= ?");
    params.push(String(req.query.from));
  }
  if (req.query.to) {
    where.push("e.criado_em <= ?");
    params.push(`${String(req.query.to)} 23:59:59`);
  }
  if (req.query.user) {
    where.push("e.usuario_id = ?");
    params.push(Number(req.query.user));
  }
  if (req.query.sku) {
    where.push("e.sku = ?");
    params.push(String(req.query.sku));
  }

  const clause = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const rows = db
    .prepare(`
      SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      ${clause}
      ORDER BY e.criado_em DESC, e.id DESC
    `)
    .all(...params);

  res.json(rows);
});

app.post("/api/addressings", (req, res) => {
  const result = addAddressing({
    sku: req.body.sku,
    shelfCode: req.body.shelfCode,
    areaCode: req.body.areaCode,
    createAddress: req.body.createAddress !== false,
    usuarioId: req.user?.id || null
  });

  if (!result.ok) {
    return res.status(result.status).json(result);
  }

  res.status(result.status).json(result);
});

app.put("/api/addressings/:id", (req, res) => {
  const id = Number(req.params.id);
  const sku = String(req.body.sku || "").trim();
  const parsed = parseShelfCode(req.body.shelfCode);
  const area = areaByCode(req.body.areaCode);

  if (!sku) {
    return res.status(400).json({ message: "SKU obrigatório." });
  }
  if (!parsed) {
    return res.status(400).json({ message: "Código de prateleira inválido. Use o padrão R01-RK01-L01-A." });
  }
  if (!area) {
    return res.status(400).json({ message: "Área Linha Separação obrigatória." });
  }

  const address = ensureAddress(parsed);

  try {
    const result = db.prepare(`
      UPDATE enderecamentos
      SET sku = ?, localizacao_id = ?, rua = ?, rack = ?, linha = ?, letra = ?, codigo_endereco = ?,
          area_linha_separacao_codigo = ?, area_linha_separacao_nome = ?,
          conferencia_obrigatoria = 0, usuario_id = COALESCE(usuario_id, ?),
          atualizado_em = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      sku,
      address.id,
      parsed.rua,
      parsed.rack,
      parsed.linha,
      parsed.letra,
      parsed.codigo_endereco,
      area.codigo,
      area.nome,
      req.user?.id || null,
      id
    );

    if (result.changes === 0) {
      return res.status(404).json({ message: "Endereçamento não encontrado." });
    }
  } catch (error) {
    if (String(error.message).includes("UNIQUE")) {
      return res.status(409).json({ message: "Este SKU já está cadastrado neste endereço." });
    }
    throw error;
  }

  logAction({
    usuarioId: req.user?.id || null,
    acao: "Endereço alterado",
    sku,
    codigoEndereco: parsed.codigo_endereco,
    detalhes: `Endereçamento ${id} atualizado`
  });

  res.json(
    db
      .prepare(`
        SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
        FROM enderecamentos e
        LEFT JOIN usuarios u ON u.id = e.usuario_id
        WHERE e.id = ?
      `)
      .get(id)
  );
});

app.delete("/api/addressings/:id", (req, res) => {
  const current = db.prepare("SELECT * FROM enderecamentos WHERE id = ?").get(Number(req.params.id));
  const result = db.prepare("DELETE FROM enderecamentos WHERE id = ?").run(Number(req.params.id));

  if (result.changes > 0 && current) {
    logAction({
      usuarioId: req.user?.id || null,
      acao: "Endereço removido",
      sku: current.sku,
      codigoEndereco: current.codigo_endereco,
      detalhes: `Endereçamento ${current.id} removido`
    });
  }

  res.json({ deleted: result.changes > 0 });
});

app.get("/api/sku/:sku", (req, res) => {
  const sku = String(req.params.sku);
  const rows = db
    .prepare(`
      SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      WHERE e.sku = ?
      ORDER BY e.criado_em DESC, e.id DESC
    `)
    .all(sku);

  logAction({
    usuarioId: req.user?.id || null,
    acao: "SKU consultado",
    sku,
    detalhes: `${rows.length} localização(ões) encontrada(s)`
  });

  res.json(rows);
});

app.get("/api/shelf/:code", (req, res) => {
  const parsed = parseShelfCode(req.params.code);
  if (!parsed) {
    return res.status(400).json({ message: "Código de prateleira inválido. Use o padrão R01-RK01-L01-A." });
  }

  const rows = db
    .prepare(`
      SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      WHERE e.codigo_endereco = ?
      ORDER BY e.sku
    `)
    .all(parsed.codigo_endereco);

  logAction({
    usuarioId: req.user?.id || null,
    acao: "Localização consultada",
    codigoEndereco: parsed.codigo_endereco,
    detalhes: `${rows.length} SKU(s) encontrado(s)`
  });

  res.json({
    address: parsed,
    totalSkus: rows.length,
    skus: rows
  });
});

app.post("/api/import", (req, res) => {
  const rows = Array.isArray(req.body.rows) ? req.body.rows : [];
  const summary = { imported: 0, skipped: 0, errors: [] };

  rows.forEach((row, index) => {
    const sku = String(row.sku || "").trim();
    const ruaNumber = String(row.rua || "").trim().match(/\d+/)?.[0] || String(row.rua || "").trim();
    const rack = String(row.rack || "").trim();
    const linha = String(row.linha || "").trim();
    const letra = String(row.letra || "").trim().toUpperCase();
    const shelfCode = `R${String(Number(ruaNumber)).padStart(2, "0")}-RK${String(Number(rack)).padStart(2, "0")}-L${String(Number(linha)).padStart(2, "0")}-${letra}`;
    const result = addAddressing({
      sku,
      shelfCode,
      areaCode: Number(row.areaCode),
      createAddress: true,
      usuarioId: req.user?.id || null
    });

    if (result.ok) {
      summary.imported += 1;
    } else if (result.status === 409) {
      summary.skipped += 1;
    } else {
      summary.errors.push({ line: index + 2, message: result.message });
    }
  });

  logAction({
    usuarioId: req.user?.id || null,
    acao: "Excel importado",
    detalhes: `${summary.imported} importado(s), ${summary.skipped} duplicidade(s), ${summary.errors.length} erro(s)`
  });

  res.json(summary);
});

app.post("/api/history", (req, res) => {
  logAction({
    usuarioId: req.user?.id || null,
    acao: String(req.body.acao || "Ação registrada"),
    sku: req.body.sku ? String(req.body.sku) : null,
    codigoEndereco: req.body.codigoEndereco ? String(req.body.codigoEndereco) : null,
    detalhes: req.body.detalhes ? String(req.body.detalhes) : null
  });
  res.status(201).json({ ok: true });
});

app.get("/api/history", (_req, res) => {
  const rows = db
    .prepare(`
      SELECT h.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM historico h
      LEFT JOIN usuarios u ON u.id = h.usuario_id
      ORDER BY h.criado_em DESC, h.id DESC
      LIMIT 300
    `)
    .all();
  res.json(rows);
});

app.get("/api/users", (_req, res) => {
  const rows = db
    .prepare("SELECT id, nome, email, perfil, ativo, criado_em, atualizado_em FROM usuarios ORDER BY nome")
    .all()
    .map(publicUser);
  res.json(rows);
});

app.post("/api/users", (req, res) => {
  const nome = String(req.body.nome || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const senha = String(req.body.senha || "");
  const perfil = String(req.body.perfil || "Operador");

  if (!nome || !email || senha.length < 4) {
    return res.status(400).json({ message: "Informe nome, e-mail e senha com pelo menos 4 caracteres." });
  }

  try {
    db.prepare(`
      INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo)
      VALUES (?, ?, ?, ?, 1)
    `).run(nome, email, hashPassword(senha), perfil);
  } catch (error) {
    if (String(error.message).includes("UNIQUE")) {
      return res.status(409).json({ message: "E-mail já cadastrado." });
    }
    throw error;
  }

  const user = db
    .prepare("SELECT id, nome, email, perfil, ativo, criado_em, atualizado_em FROM usuarios WHERE id = last_insert_rowid()")
    .get();
  res.status(201).json(publicUser(user));
});

app.use((error, _req, res, _next) => {
  console.error(error);
  res.status(500).json({ message: "Erro interno do servidor." });
});

if (existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get(/^(?!\/api).*/, (_req, res) => {
    res.sendFile(resolve(distDir, "index.html"));
  });
}

app.listen(port, host, () => {
  console.log(`API de endereçamento rodando em http://${host}:${port}`);
});
