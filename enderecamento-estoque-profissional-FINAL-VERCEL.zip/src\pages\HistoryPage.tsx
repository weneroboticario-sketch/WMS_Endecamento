import { History } from "lucide-react";
import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { formatDateTime } from "../lib/address";
import type { HistoryEntry } from "../types";

export function HistoryPage() {
  const [rows, setRows] = useState<HistoryEntry[]>([]);

  useEffect(() => {
    api.history().then(setRows);
  }, []);

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Auditoria</span>
          <h1>Histórico de Ações</h1>
        </div>
      </div>

      <section className="panel">
        <div className="panel-title">
          <History size={18} />
          <h2>Últimos registros</h2>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Data e hora</th>
                <th>Usuário</th>
                <th>Ação</th>
                <th>SKU</th>
                <th>Endereço</th>
                <th>Detalhes</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{formatDateTime(row.criado_em)}</td>
                  <td>{row.usuario_nome || "Sem usuário"}</td>
                  <td>{row.acao}</td>
                  <td>{row.sku || "-"}</td>
                  <td>{row.codigo_endereco || "-"}</td>
                  <td>{row.detalhes || "-"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
