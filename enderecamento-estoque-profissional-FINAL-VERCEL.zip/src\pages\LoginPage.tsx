import { Boxes, LogIn } from "lucide-react";
import { FormEvent, useState } from "react";
import { api } from "../lib/api";
import type { User } from "../types";

export function LoginPage({ onLogin }: { onLogin: (auth: { token: string; user: User }) => void }) {
  const [email, setEmail] = useState("operador@estoque.local");
  const [password, setPassword] = useState("operador123");
  const [message, setMessage] = useState("");

  async function login(event: FormEvent) {
    event.preventDefault();
    setMessage("");
    try {
      const auth = await api.login({ email, password });
      onLogin(auth);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Falha no login.");
    }
  }

  return (
    <main className="login-screen">
      <form className="login-card" onSubmit={login}>
        <div className="login-brand">
          <Boxes size={34} />
          <div>
            <strong>Estoque Pro</strong>
            <span>Gestão de Endereçamento</span>
          </div>
        </div>

        <label className="field">
          <span>Usuário ou e-mail</span>
          <input value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="username" />
        </label>

        <label className="field">
          <span>Senha</span>
          <input
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            type="password"
            autoComplete="current-password"
          />
        </label>

        {message && <div className="system-message error">{message}</div>}

        <button className="primary large-action" type="submit">
          <LogIn size={19} />
          Entrar
        </button>

        <div className="login-help">
          <strong>Usuários de teste</strong>
          <span>admin@estoque.local / admin123</span>
          <span>supervisor@estoque.local / supervisor123</span>
          <span>operador@estoque.local / operador123</span>
        </div>
      </form>
    </main>
  );
}
