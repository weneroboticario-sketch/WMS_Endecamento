import type { Addressing, Area, HistoryEntry, ParsedShelf, User } from "../types";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const auth = localStorage.getItem("enderecamento.auth");
  const token = auth ? JSON.parse(auth).token : "";
  const response = await fetch(path, {
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options?.headers || {})
    },
    ...options
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(data?.message || data?.result?.message || "Erro ao processar solicitação.");
  }

  return data as T;
}

export const api = {
  login: (payload: { email: string; password: string }) =>
    request<{ token: string; user: User }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  me: () => request<User>("/api/auth/me"),
  areas: () => request<Area[]>("/api/areas"),
  dashboard: () =>
    request<{
      totals: {
        produtosEnderecados: number;
        vinculosSkuEndereco: number;
        localizacoesCriadas: number;
        skusDistintos: number;
      };
      byArea: Array<{ codigo: number; nome: string; total: number }>;
      latest: Addressing[];
      topShelves: Array<{ codigo_endereco: string; rua: string; rack: number; linha: number; letra: string; total: number }>;
      byUser: Array<{ nome: string; total: number }>;
    }>("/api/dashboard"),
  checkAddress: (code: string) =>
    request<{ exists: boolean; address: ParsedShelf | Addressing }>(
      `/api/addresses/check/${encodeURIComponent(code)}`
    ),
  createAddressing: (payload: {
    sku: string;
    shelfCode: string;
    areaCode: number;
    createAddress: boolean;
  }) =>
    request<{ message: string; record: Addressing }>("/api/addressings", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  listAddressings: (filters?: Record<string, string>) => {
    const query = new URLSearchParams(filters || {});
    return request<Addressing[]>(`/api/addressings${query.size ? `?${query}` : ""}`);
  },
  updateAddressing: (id: number, payload: { sku: string; shelfCode: string; areaCode: number }) =>
    request<Addressing>(`/api/addressings/${id}`, {
      method: "PUT",
      body: JSON.stringify(payload)
    }),
  deleteAddressing: (id: number) =>
    request<{ deleted: boolean }>(`/api/addressings/${id}`, {
      method: "DELETE"
    }),
  searchSku: (sku: string) => request<Addressing[]>(`/api/sku/${encodeURIComponent(sku)}`),
  searchShelf: (code: string) =>
    request<{ address: ParsedShelf; totalSkus: number; skus: Addressing[] }>(
      `/api/shelf/${encodeURIComponent(code)}`
    ),
  importRows: (rows: Array<Record<string, string | number>>) =>
    request<{ imported: number; skipped: number; errors: Array<{ line: number; message: string }> }>(
      "/api/import",
      {
        method: "POST",
        body: JSON.stringify({ rows })
      }
    ),
  history: () => request<HistoryEntry[]>("/api/history"),
  logHistory: (payload: { acao: string; sku?: string; codigoEndereco?: string; detalhes?: string }) =>
    request<{ ok: boolean }>("/api/history", {
      method: "POST",
      body: JSON.stringify(payload)
    }),
  users: () => request<User[]>("/api/users"),
  createUser: (payload: { nome: string; email: string; senha: string; perfil: User["perfil"] }) =>
    request<User>("/api/users", {
      method: "POST",
      body: JSON.stringify(payload)
    })
};
