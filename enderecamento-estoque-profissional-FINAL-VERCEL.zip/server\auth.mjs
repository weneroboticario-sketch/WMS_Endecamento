import crypto from "node:crypto";
import { db } from "./db.mjs";

const secret = process.env.AUTH_SECRET || "estoque-pro-local-secret";

export function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.pbkdf2Sync(String(password), salt, 120000, 32, "sha256").toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password, storedHash) {
  const [salt, hash] = String(storedHash || "").split(":");
  if (!salt || !hash) {
    return false;
  }

  const candidate = hashPassword(password, salt).split(":")[1];
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(candidate, "hex"));
}

export function createToken(user) {
  const payload = {
    sub: user.id,
    nome: user.nome,
    email: user.email,
    perfil: user.perfil,
    exp: Date.now() + 1000 * 60 * 60 * 12
  };
  const body = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return `${body}.${signature}`;
}

export function readToken(token) {
  const [body, signature] = String(token || "").split(".");
  if (!body || !signature) {
    return null;
  }

  const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  if (expected !== signature) {
    return null;
  }

  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  if (payload.exp < Date.now()) {
    return null;
  }

  const user = db
    .prepare("SELECT id, nome, email, perfil, ativo, criado_em, atualizado_em FROM usuarios WHERE id = ?")
    .get(payload.sub);

  return user?.ativo ? user : null;
}

export function publicUser(user) {
  return {
    id: user.id,
    nome: user.nome,
    email: user.email,
    perfil: user.perfil,
    ativo: Boolean(user.ativo),
    criado_em: user.criado_em,
    atualizado_em: user.atualizado_em
  };
}
