import JsBarcode from "jsbarcode";
import { jsPDF } from "jspdf";
import { Download, FileSpreadsheet, Printer, Tags } from "lucide-react";
import { ChangeEvent, FormEvent, useMemo, useState } from "react";
import { BarcodeLabel } from "../components/BarcodeLabel";
import { api } from "../lib/api";
import { generateShelfCodes } from "../lib/address";
import { parseShelfCodesFromExcel } from "../lib/excel";

export function Labels() {
  const [singleCode, setSingleCode] = useState("R01-RK01-L01-A");
  const [batch, setBatch] = useState({
    ruaInicial: 1,
    ruaFinal: 1,
    rackInicial: 1,
    rackFinal: 1,
    linhaInicial: 1,
    linhaFinal: 3,
    letraInicial: "A",
    letraFinal: "G"
  });
  const [codes, setCodes] = useState<string[]>(["R01-RK01-L01-A"]);
  const [spreadsheetSource, setSpreadsheetSource] = useState("");
  const [spreadsheetMessage, setSpreadsheetMessage] = useState("");

  const totalPreview = useMemo(() => codes.length, [codes]);

  function generateSingle(event: FormEvent) {
    event.preventDefault();
    setCodes([singleCode.trim().toUpperCase()]);
    setSpreadsheetSource("");
    setSpreadsheetMessage("");
    api.logHistory({ acao: "Etiqueta gerada", codigoEndereco: singleCode.trim().toUpperCase(), detalhes: "Etiqueta individual" });
  }

  function generateBatch(event: FormEvent) {
    event.preventDefault();
    const generated = generateShelfCodes(batch);
    setCodes(generated);
    setSpreadsheetSource("");
    setSpreadsheetMessage("");
    api.logHistory({ acao: "Etiqueta gerada", detalhes: `${generated.length} etiqueta(s) em lote` });
  }

  async function generateFromSpreadsheet(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }

    const shelves = await parseShelfCodesFromExcel(file);
    setCodes(shelves.map((shelf) => shelf.code));
    setSpreadsheetSource(file.name);
    setSpreadsheetMessage(`${shelves.length} endereço(s) único(s) lido(s) da planilha.`);
    api.logHistory({ acao: "Etiqueta gerada", detalhes: `${shelves.length} etiqueta(s) pela planilha ${file.name}` });
  }

  function printLabels() {
    window.print();
  }

  function downloadPdf() {
    const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
    const width = 86;
    const height = 38;
    const marginX = 12;
    const marginY = 12;
    let x = marginX;
    let y = marginY;

    codes.forEach((code, index) => {
      if (index > 0 && x + width > 200) {
        x = marginX;
        y += height + 7;
      }
      if (y + height > 285) {
        pdf.addPage();
        x = marginX;
        y = marginY;
      }

      const canvas = document.createElement("canvas");
      JsBarcode(canvas, code, {
        format: "CODE128",
        width: 2,
        height: 56,
        displayValue: false,
        margin: 8
      });

      pdf.roundedRect(x, y, width, height, 1.5, 1.5);
      pdf.addImage(canvas.toDataURL("image/png"), "PNG", x + 4, y + 5, width - 8, 18);
      pdf.setFontSize(13);
      pdf.text(code, x + width / 2, y + 30, { align: "center" });
      x += width + 7;
    });

    pdf.save("etiquetas-prateleiras.pdf");
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">CODE128</span>
          <h1>Gerar Etiquetas de Prateleira</h1>
        </div>
        <div className="button-row">
          <button className="secondary" onClick={printLabels} type="button">
            <Printer size={18} />
            Imprimir
          </button>
          <button className="primary" onClick={downloadPdf} type="button">
            <Download size={18} />
            Baixar PDF
          </button>
        </div>
      </div>

      <div className="labels-controls">
        <form className="panel form-grid" onSubmit={generateSingle}>
          <div className="panel-title">
            <Tags size={18} />
            <h2>Etiqueta individual</h2>
          </div>
          <label className="field wide">
            <span>Código da Prateleira</span>
            <input value={singleCode} onChange={(event) => setSingleCode(event.target.value.toUpperCase())} />
          </label>
          <button className="secondary" type="submit">Gerar individual</button>
        </form>

        <form className="panel form-grid compact" onSubmit={generateBatch}>
          <div className="panel-title wide">
            <Tags size={18} />
            <h2>Etiquetas em lote</h2>
          </div>
          {[
            ["ruaInicial", "Rua inicial"],
            ["ruaFinal", "Rua final"],
            ["rackInicial", "Rack inicial"],
            ["rackFinal", "Rack final"],
            ["linhaInicial", "Linha inicial"],
            ["linhaFinal", "Linha final"]
          ].map(([key, label]) => (
            <label className="field" key={key}>
              <span>{label}</span>
              <input
                type="number"
                min="1"
                value={batch[key as keyof typeof batch]}
                onChange={(event) => setBatch({ ...batch, [key]: Number(event.target.value) })}
              />
            </label>
          ))}
          <label className="field">
            <span>Letra inicial</span>
            <input value={batch.letraInicial} onChange={(event) => setBatch({ ...batch, letraInicial: event.target.value.toUpperCase() })} />
          </label>
          <label className="field">
            <span>Letra final</span>
            <input value={batch.letraFinal} onChange={(event) => setBatch({ ...batch, letraFinal: event.target.value.toUpperCase() })} />
          </label>
          <button className="secondary wide" type="submit">Gerar lote</button>
        </form>

        <section className="panel spreadsheet-labels">
          <div className="panel-title">
            <FileSpreadsheet size={18} />
            <h2>Etiquetas pela planilha</h2>
          </div>
          <label className="mini-upload">
            <FileSpreadsheet size={28} />
            <strong>{spreadsheetSource || "Ler planilha LinhaSeparacao"}</strong>
            <span>Usa Nome estacao, Nr Rack, Linha e Coluna para gerar os códigos de barras.</span>
            <input accept=".xlsx,.xls" onChange={generateFromSpreadsheet} type="file" />
          </label>
          {spreadsheetMessage && <div className="system-message ok">{spreadsheetMessage}</div>}
        </section>
      </div>

      <div className="result-count">{totalPreview} etiqueta(s) gerada(s)</div>
      <div className="labels-grid print-area">
        {codes.map((code) => (
          <BarcodeLabel code={code} key={code} />
        ))}
      </div>
    </section>
  );
}
