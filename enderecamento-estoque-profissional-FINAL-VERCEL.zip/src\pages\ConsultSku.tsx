import { Edit3, PackageSearch, Save, Trash2, X } from "lucide-react";
import { FormEvent, useState } from "react";
import { api } from "../lib/api";
import { formatDateTime } from "../lib/address";
import type { Addressing } from "../types";

export function ConsultSku() {
  const [sku, setSku] = useState("");
  const [results, setResults] = useState<Addressing[]>([]);
  const [message, setMessage] = useState("");
  const [editing, setEditing] = useState<Addressing | null>(null);

  async function search(event?: FormEvent) {
    event?.preventDefault();
    if (!sku.trim()) {
      return;
    }

    const rows = await api.searchSku(sku.trim());
    setResults(rows);
    setMessage(rows.length ? `${rows.length} localização(ões) encontrada(s).` : "Nenhuma localização encontrada.");
  }

  async function remove(row: Addressing) {
    await api.deleteAddressing(row.id);
    setResults((current) => current.filter((item) => item.id !== row.id));
    setMessage("Endereçamento removido.");
  }

  async function saveEdit(event: FormEvent) {
    event.preventDefault();
    if (!editing) {
      return;
    }

    const updated = await api.updateAddressing(editing.id, {
      sku: editing.sku,
      shelfCode: editing.codigo_endereco,
      areaCode: editing.area_linha_separacao_codigo
    });

    setResults((current) => current.map((item) => (item.id === updated.id ? updated : item)));
    setEditing(null);
    setMessage("Endereçamento atualizado.");
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Pesquisa operacional</span>
          <h1>Consultar SKU</h1>
        </div>
      </div>

      <form className="search-row" onSubmit={search}>
        <label className="field">
          <span>Código Material</span>
          <input
            value={sku}
            onChange={(event) => setSku(event.target.value)}
            placeholder="Bipe ou digite o SKU"
            autoComplete="off"
          />
        </label>
        <button className="primary" type="submit">
          <PackageSearch size={18} />
          Consultar
        </button>
      </form>

      {message && <div className="system-message ok">{message}</div>}

      <div className="table-wrap panel-table">
        <table>
          <thead>
            <tr>
              <th>Código Material</th>
              <th>Rua</th>
              <th>Rack</th>
              <th>Linha</th>
              <th>Letra</th>
              <th>Área Linha Separação</th>
              <th>Data e hora</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody>
            {results.map((row) => (
              <tr key={row.id}>
                <td>{row.sku}</td>
                <td>{row.rua}</td>
                <td>{row.rack}</td>
                <td>{row.linha}</td>
                <td>{row.letra}</td>
                <td>{row.area_linha_separacao_nome}</td>
                <td>{formatDateTime(row.criado_em)}</td>
                <td className="actions">
                  <button className="icon-button" onClick={() => setEditing(row)} type="button" title="Editar">
                    <Edit3 size={17} />
                  </button>
                  <button className="icon-button danger" onClick={() => remove(row)} type="button" title="Remover">
                    <Trash2 size={17} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <div className="modal-backdrop">
          <form className="modal" onSubmit={saveEdit}>
            <div className="modal-header">
              <h2>Editar localização</h2>
              <button className="icon-button" onClick={() => setEditing(null)} type="button" title="Fechar">
                <X size={18} />
              </button>
            </div>
            <label className="field">
              <span>Código Material</span>
              <input value={editing.sku} onChange={(event) => setEditing({ ...editing, sku: event.target.value })} />
            </label>
            <label className="field">
              <span>Código da Prateleira</span>
              <input
                value={editing.codigo_endereco}
                onChange={(event) => setEditing({ ...editing, codigo_endereco: event.target.value.toUpperCase() })}
              />
            </label>
            <label className="field">
              <span>Área Linha Separação</span>
              <select
                value={editing.area_linha_separacao_codigo}
                onChange={(event) =>
                  setEditing({ ...editing, area_linha_separacao_codigo: Number(event.target.value) })
                }
              >
                <option value="1">1 - Alto Giro</option>
                <option value="2">2 - Médio Giro</option>
                <option value="3">3 - Área RF</option>
                <option value="4">4 - Baixo Giro</option>
                <option value="5">5 - Picking by Light</option>
              </select>
            </label>
            <button className="primary" type="submit">
              <Save size={18} />
              Salvar Alteração
            </button>
          </form>
        </div>
      )}
    </section>
  );
}
