export type Area = {
  codigo: number;
  nome: string;
};

export type User = {
  id: number;
  nome: string;
  email: string;
  perfil: "Administrador" | "Supervisor" | "Operador";
  ativo: boolean;
  criado_em: string;
  atualizado_em: string;
};

export type Addressing = {
  id: number;
  sku: string;
  rua: string;
  rack: number;
  linha: number;
  letra: string;
  codigo_endereco: string;
  area_linha_separacao_codigo: number;
  area_linha_separacao_nome: string;
  conferencia_obrigatoria: number;
  usuario_id?: number | null;
  usuario_nome?: string | null;
  usuario_email?: string | null;
  criado_em: string;
  atualizado_em: string;
};

export type HistoryEntry = {
  id: number;
  usuario_id: number | null;
  usuario_nome: string | null;
  usuario_email: string | null;
  acao: string;
  sku: string | null;
  codigo_endereco: string | null;
  detalhes: string | null;
  criado_em: string;
};

export type ParsedShelf = {
  rua: string;
  ruaNumero: number;
  rack: number;
  linha: number;
  letra: string;
  codigo_endereco: string;
};

export type Settings = {
  ruaPrefix: string;
  rackPrefix: string;
  linhaPrefix: string;
  digits: number;
  shelfPattern: string;
  autoCreateAddress: boolean;
  enableCamera: boolean;
  autoSave: boolean;
};
