import * as XLSX from "xlsx";
import type { Addressing } from "../types";
import { buildShelfCode } from "./address";

export const EXPORT_COLUMNS = [
  "Nome estacao",
  "Nr Rack",
  "Area Linha Separaçao",
  "Linha",
  "Coluna",
  "Codigo Material",
  "Conferencia Obrigatoria"
] as const;

export function exportAddressingsToExcel(rows: Addressing[]) {
  const data = rows.map((row) => ({
    "Nome estacao": row.rua,
    "Nr Rack": row.rack,
    "Area Linha Separaçao": row.area_linha_separacao_codigo,
    Linha: row.linha,
    Coluna: row.letra,
    "Codigo Material": String(row.sku),
    "Conferencia Obrigatoria": 0
  }));

  const worksheet = XLSX.utils.json_to_sheet(data, { header: [...EXPORT_COLUMNS] });
  worksheet["!cols"] = [
    { wch: 16 },
    { wch: 10 },
    { wch: 22 },
    { wch: 10 },
    { wch: 10 },
    { wch: 18 },
    { wch: 26 }
  ];
  for (let row = 2; row <= data.length + 1; row += 1) {
    const cell = worksheet[`F${row}`];
    if (cell) {
      cell.t = "s";
      cell.z = "@";
      cell.v = String(cell.v);
    }
  }
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "LinhaSeparacao");
  XLSX.writeFile(workbook, `LinhaSeparacao_Enderecamento_${formatBrazilianDate(new Date())}.xlsx`);
}

export async function parseImportFile(file: File) {
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array", cellText: false, cellDates: true });
  const sheet = workbook.Sheets.LinhaSeparacao || workbook.Sheets[workbook.SheetNames[0]];
  validateRequiredColumns(sheet);
  const rows = XLSX.utils.sheet_to_json<Record<string, string | number>>(sheet, { defval: "" });

  return rows.map((row) => {
    const rua = cleanCell(row["Nome estacao"]);
    const rack = cleanCell(row["Nr Rack"]);
    const area =
      row["Area Linha Separaçao"] ||
      row["Area Linha Separação"] ||
      row["Area Linha Separacao"] ||
      "";
    const linha = cleanCell(row.Linha);
    const letra = cleanCell(row.Coluna).toUpperCase();

    return {
      rua,
      rack,
      areaCode: Number(cleanCell(area)),
      linha,
      letra,
      sku: cleanCell(row["Codigo Material"]),
      conferencia: Number(row["Conferencia Obrigatoria"] || 0)
    };
  });
}

export async function parseShelfCodesFromExcel(file: File) {
  const rows = await parseImportFile(file);
  const seen = new Set<string>();

  return rows
    .map((row) => {
      const ruaNumero = Number(String(row.rua).match(/\d+/)?.[0] || row.rua);
      const rack = Number(row.rack);
      const linha = Number(row.linha);
      const letra = String(row.letra || "").trim().toUpperCase();

      if (!ruaNumero || !rack || !linha || !/^[A-Z]+$/.test(letra)) {
        return null;
      }

      const code = buildShelfCode(ruaNumero, rack, linha, letra);
      return {
        code,
        sku: row.sku,
        areaCode: row.areaCode,
        source: row
      };
    })
    .filter((item): item is NonNullable<typeof item> => Boolean(item))
    .filter((item) => {
      if (seen.has(item.code)) {
        return false;
      }
      seen.add(item.code);
      return true;
    });
}

function cleanCell(value: unknown) {
  return String(value ?? "").trim();
}

function validateRequiredColumns(sheet: XLSX.WorkSheet) {
  const header = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1, defval: "" })[0] || [];
  const normalized = header.map((item) => cleanCell(item));

  for (const column of EXPORT_COLUMNS) {
    if (!normalized.includes(column)) {
      throw new Error(`Coluna obrigatória ausente: ${column}`);
    }
  }
}

function formatBrazilianDate(date: Date) {
  const day = String(date.getDate()).padStart(2, "0");
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
}
