import type { ParsedShelf, Settings } from "../types";

export const defaultSettings: Settings = {
  ruaPrefix: "R",
  rackPrefix: "RK",
  linhaPrefix: "L",
  digits: 2,
  shelfPattern: "R01-RK01-L01-A",
  autoCreateAddress: true,
  enableCamera: true,
  autoSave: true
};

export function padNumber(value: number | string, digits = 2) {
  return String(Number(value || 0)).padStart(digits, "0");
}

export function buildShelfCode(
  rua: number | string,
  rack: number | string,
  linha: number | string,
  letra: string,
  settings: Settings = defaultSettings
) {
  return `${settings.ruaPrefix}${padNumber(rua, settings.digits)}-${settings.rackPrefix}${padNumber(rack, settings.digits)}-${settings.linhaPrefix}${padNumber(linha, settings.digits)}-${letterToIndex(letra) ? letra.trim().toUpperCase() : "A"}`;
}

export function parseShelfCode(rawCode: string): ParsedShelf | null {
  const code = rawCode.trim().toUpperCase();
  const match = code.match(/^R(\d+)-RK(\d+)-L(\d+)-([A-Z]+)$/);

  if (!match) {
    return null;
  }

  const ruaNumero = Number(match[1]);
  const rack = Number(match[2]);
  const linha = Number(match[3]);
  const letra = match[4];

  return {
    rua: `Rua ${padNumber(ruaNumero)}`,
    ruaNumero,
    rack,
    linha,
    letra,
    codigo_endereco: `R${padNumber(ruaNumero)}-RK${padNumber(rack)}-L${padNumber(linha)}-${letra}`
  };
}

export function letterToIndex(letter: string) {
  const clean = letter.trim().toUpperCase();
  if (!/^[A-Z]+$/.test(clean)) {
    return 0;
  }

  return clean.split("").reduce((total, char) => total * 26 + char.charCodeAt(0) - 64, 0);
}

export function indexToLetter(index: number) {
  let value = index;
  let result = "";

  while (value > 0) {
    const remainder = (value - 1) % 26;
    result = String.fromCharCode(65 + remainder) + result;
    value = Math.floor((value - 1) / 26);
  }

  return result;
}

export function generateShelfCodes(input: {
  ruaInicial: number;
  ruaFinal: number;
  rackInicial: number;
  rackFinal: number;
  linhaInicial: number;
  linhaFinal: number;
  letraInicial: string;
  letraFinal: string;
}) {
  const codes: string[] = [];
  const firstLetter = letterToIndex(input.letraInicial);
  const lastLetter = letterToIndex(input.letraFinal);

  if (!firstLetter || !lastLetter || firstLetter > lastLetter) {
    return codes;
  }

  for (let rua = input.ruaInicial; rua <= input.ruaFinal; rua += 1) {
    for (let rack = input.rackInicial; rack <= input.rackFinal; rack += 1) {
      for (let linha = input.linhaInicial; linha <= input.linhaFinal; linha += 1) {
        for (let letter = firstLetter; letter <= lastLetter; letter += 1) {
          codes.push(buildShelfCode(rua, rack, linha, indexToLetter(letter)));
        }
      }
    }
  }

  return codes;
}

export function formatDateTime(value: string) {
  const raw = String(value || "");
  const date = raw.includes("T") ? new Date(raw) : new Date(`${raw.replace(" ", "T")}Z`);
  return new Intl.DateTimeFormat("pt-BR", {
    dateStyle: "short",
    timeStyle: "short"
  }).format(date);
}
