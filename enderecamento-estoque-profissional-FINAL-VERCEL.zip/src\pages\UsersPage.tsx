import { Plus, Users } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { api } from "../lib/api";
import type { User } from "../types";

export function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [draft, setDraft] = useState({
    nome: "",
    email: "",
    senha: "",
    perfil: "Operador" as User["perfil"]
  });
  const [message, setMessage] = useState("");

  useEffect(() => {
    api.users().then(setUsers);
  }, []);

  async function create(event: FormEvent) {
    event.preventDefault();
    try {
      const user = await api.createUser(draft);
      setUsers((current) => [...current, user].sort((a, b) => a.nome.localeCompare(b.nome)));
      setDraft({ nome: "", email: "", senha: "", perfil: "Operador" });
      setMessage("Usuário criado com sucesso.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Erro ao criar usuário.");
    }
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Acesso multiusuário</span>
          <h1>Usuários</h1>
        </div>
      </div>

      <form className="panel filter-grid users-form" onSubmit={create}>
        <label className="field">
          <span>Nome</span>
          <input value={draft.nome} onChange={(event) => setDraft({ ...draft, nome: event.target.value })} />
        </label>
        <label className="field">
          <span>E-mail</span>
          <input value={draft.email} onChange={(event) => setDraft({ ...draft, email: event.target.value })} />
        </label>
        <label className="field">
          <span>Senha</span>
          <input
            value={draft.senha}
            onChange={(event) => setDraft({ ...draft, senha: event.target.value })}
            type="password"
          />
        </label>
        <label className="field">
          <span>Perfil</span>
          <select
            value={draft.perfil}
            onChange={(event) => setDraft({ ...draft, perfil: event.target.value as User["perfil"] })}
          >
            <option>Administrador</option>
            <option>Supervisor</option>
            <option>Operador</option>
          </select>
        </label>
        <button className="primary" type="submit">
          <Plus size={18} />
          Criar usuário
        </button>
      </form>

      {message && <div className="system-message ok">{message}</div>}

      <section className="panel">
        <div className="panel-title">
          <Users size={18} />
          <h2>Usuários cadastrados</h2>
        </div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Perfil</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user.id}>
                  <td>{user.nome}</td>
                  <td>{user.email}</td>
                  <td>{user.perfil}</td>
                  <td>{user.ativo ? "Ativo" : "Inativo"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
