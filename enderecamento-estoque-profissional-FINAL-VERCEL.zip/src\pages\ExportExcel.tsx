import { Download, Filter } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";
import { api } from "../lib/api";
import { exportAddressingsToExcel } from "../lib/excel";
import type { Addressing, Area, User } from "../types";

export function ExportExcel() {
  const [areas, setAreas] = useState<Area[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [rows, setRows] = useState<Addressing[]>([]);
  const [filters, setFilters] = useState({ area: "", rua: "", rack: "", from: "", to: "", user: "", sku: "" });
  const [message, setMessage] = useState("");

  useEffect(() => {
    api.areas().then(setAreas);
    api.users().then(setUsers);
    loadRows();
  }, []);

  async function loadRows(event?: FormEvent) {
    event?.preventDefault();
    const clean = Object.fromEntries(Object.entries(filters).filter(([, value]) => value));
    const data = await api.listAddressings(clean);
    setRows(data);
    setMessage(`${data.length} registro(s) pronto(s) para exportação.`);
  }

  async function exportFile() {
    exportAddressingsToExcel(rows);
    await api.logHistory({ acao: "Excel exportado", detalhes: `${rows.length} registro(s) exportado(s)` });
    setMessage("Exportação concluída com sucesso.");
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Modelo LinhaSeparacao</span>
          <h1>Exportar Excel</h1>
        </div>
        <button className="primary" onClick={exportFile} type="button" disabled={!rows.length}>
          <Download size={18} />
          Baixar .xlsx
        </button>
      </div>

      <form className="panel filter-grid" onSubmit={loadRows}>
        <label className="field">
          <span>Área</span>
          <select value={filters.area} onChange={(event) => setFilters({ ...filters, area: event.target.value })}>
            <option value="">Todas</option>
            {areas.map((area) => (
              <option key={area.codigo} value={area.codigo}>
                {area.codigo} - {area.nome}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>Rua</span>
          <input placeholder="Rua 01" value={filters.rua} onChange={(event) => setFilters({ ...filters, rua: event.target.value })} />
        </label>
        <label className="field">
          <span>Rack</span>
          <input type="number" min="1" value={filters.rack} onChange={(event) => setFilters({ ...filters, rack: event.target.value })} />
        </label>
        <label className="field">
          <span>De</span>
          <input type="date" value={filters.from} onChange={(event) => setFilters({ ...filters, from: event.target.value })} />
        </label>
        <label className="field">
          <span>Até</span>
          <input type="date" value={filters.to} onChange={(event) => setFilters({ ...filters, to: event.target.value })} />
        </label>
        <label className="field">
          <span>Usuário</span>
          <select value={filters.user} onChange={(event) => setFilters({ ...filters, user: event.target.value })}>
            <option value="">Todos</option>
            {users.map((user) => (
              <option key={user.id} value={user.id}>
                {user.nome}
              </option>
            ))}
          </select>
        </label>
        <label className="field">
          <span>SKU</span>
          <input value={filters.sku} onChange={(event) => setFilters({ ...filters, sku: event.target.value })} />
        </label>
        <button className="secondary" type="submit">
          <Filter size={18} />
          Aplicar filtros
        </button>
      </form>

      {message && <div className="system-message ok">{message}</div>}

      <section className="panel">
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Nome estacao</th>
                <th>Nr Rack</th>
                <th>Area Linha Separaçao</th>
                <th>Linha</th>
                <th>Coluna</th>
                <th>Codigo Material</th>
                <th>Conferencia Obrigatoria</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.id}>
                  <td>{row.rua}</td>
                  <td>{row.rack}</td>
                  <td>{row.area_linha_separacao_codigo}</td>
                  <td>{row.linha}</td>
                  <td>{row.letra}</td>
                  <td>{row.sku}</td>
                  <td>0</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </section>
  );
}
