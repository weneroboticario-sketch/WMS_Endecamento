import crypto from "node:crypto";

const AREAS = [
  { codigo: 1, nome: "Alto Giro" },
  { codigo: 2, nome: "Médio Giro" },
  { codigo: 3, nome: "Área RF" },
  { codigo: 4, nome: "Baixo Giro" },
  { codigo: 5, nome: "Picking by Light" }
];

const secret = process.env.AUTH_SECRET || "estoque-pro-vercel-secret";
let sqlClient;
let initialized = false;

const memory = {
  users: [],
  localizacoes: [],
  enderecamentos: [],
  historico: [],
  nextUser: 1,
  nextLoc: 1,
  nextEnd: 1,
  nextHist: 1,
  initialized: false
};

export default async function handler(req, res) {
  setCors(res);

  if (req.method === "OPTIONS") {
    return res.status(204).end();
  }

  try {
    const url = new URL(req.url, "https://vercel.local");
    const path = url.pathname.replace(/^\/api/, "") || "/";
    const query = Object.fromEntries(url.searchParams.entries());
    const body = await readBody(req);
    await initStore();
    const user = await getUserFromRequest(req);

    if (req.method === "GET" && path === "/health") return json(res, { ok: true, storage: hasDatabase() ? "postgres" : "memory" });
    if (req.method === "POST" && path === "/auth/login") return login(res, body);
    if (req.method === "GET" && path === "/auth/me") return user ? json(res, publicUser(user)) : error(res, 401, "Sessão inválida.");
    if (req.method === "GET" && path === "/areas") return json(res, AREAS);
    if (req.method === "GET" && path === "/dashboard") return dashboard(res);
    if (req.method === "GET" && path.startsWith("/addresses/check/")) return checkAddress(res, decodeLast(path));
    if (req.method === "POST" && path === "/addresses") return createAddress(res, body.shelfCode);
    if (req.method === "GET" && path === "/addressings") return listAddressings(res, query);
    if (req.method === "POST" && path === "/addressings") return createAddressing(res, body, user);
    if (req.method === "PUT" && path.startsWith("/addressings/")) return updateAddressing(res, Number(decodeLast(path)), body, user);
    if (req.method === "DELETE" && path.startsWith("/addressings/")) return deleteAddressing(res, Number(decodeLast(path)), user);
    if (req.method === "GET" && path.startsWith("/sku/")) return searchSku(res, decodeLast(path), user);
    if (req.method === "GET" && path.startsWith("/shelf/")) return searchShelf(res, decodeLast(path), user);
    if (req.method === "POST" && path === "/import") return importRows(res, body.rows || [], user);
    if (req.method === "GET" && path === "/history") return history(res);
    if (req.method === "POST" && path === "/history") return createHistory(res, body, user);
    if (req.method === "GET" && path === "/users") return users(res);
    if (req.method === "POST" && path === "/users") return createUser(res, body);

    return error(res, 404, "Rota não encontrada.");
  } catch (err) {
    console.error(err);
    return error(res, 500, "Erro interno do servidor.");
  }
}

function hasDatabase() {
  return Boolean(process.env.DATABASE_URL);
}

async function getSql() {
  if (!hasDatabase()) return null;
  if (!sqlClient) {
    const postgres = (await import("postgres")).default;
    sqlClient = postgres(process.env.DATABASE_URL, {
      max: 1,
      ssl: process.env.DATABASE_URL.includes("sslmode=disable") ? false : "require"
    });
  }
  return sqlClient;
}

async function initStore() {
  if (initialized) return;
  if (hasDatabase()) {
    await initPostgres();
  } else {
    initMemory();
  }
  initialized = true;
}

async function initPostgres() {
  const sql = await getSql();
  await sql`
    CREATE TABLE IF NOT EXISTS usuarios (
      id SERIAL PRIMARY KEY,
      nome TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      senha_hash TEXT NOT NULL,
      perfil TEXT NOT NULL,
      ativo BOOLEAN NOT NULL DEFAULT TRUE,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS localizacoes (
      id SERIAL PRIMARY KEY,
      rua TEXT NOT NULL,
      rack INTEGER NOT NULL,
      linha INTEGER NOT NULL,
      letra TEXT NOT NULL,
      codigo_endereco TEXT NOT NULL UNIQUE,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS enderecamentos (
      id SERIAL PRIMARY KEY,
      sku TEXT NOT NULL,
      localizacao_id INTEGER,
      rua TEXT NOT NULL,
      rack INTEGER NOT NULL,
      linha INTEGER NOT NULL,
      letra TEXT NOT NULL,
      codigo_endereco TEXT NOT NULL,
      area_linha_separacao_codigo INTEGER NOT NULL,
      area_linha_separacao_nome TEXT NOT NULL,
      conferencia_obrigatoria INTEGER NOT NULL DEFAULT 0,
      usuario_id INTEGER,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      atualizado_em TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (sku, codigo_endereco)
    )
  `;
  await sql`
    CREATE TABLE IF NOT EXISTS historico (
      id SERIAL PRIMARY KEY,
      usuario_id INTEGER,
      acao TEXT NOT NULL,
      sku TEXT,
      codigo_endereco TEXT,
      detalhes TEXT,
      criado_em TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `;

  for (const [nome, email, senha, perfil] of defaultUsers()) {
    await sql`
      INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo)
      VALUES (${nome}, ${email}, ${hashPassword(senha)}, ${perfil}, TRUE)
      ON CONFLICT (email) DO NOTHING
    `;
  }

  const admin = await sql`SELECT id FROM usuarios WHERE email = 'admin@estoque.local' LIMIT 1`;
  for (const [sku, code, area] of defaultAddressings()) {
    await addAddressing({ sku, shelfCode: code, areaCode: area, createAddress: true, usuarioId: admin[0]?.id || null });
  }
}

function initMemory() {
  if (memory.initialized) return;
  for (const [nome, email, senha, perfil] of defaultUsers()) {
    memory.users.push({
      id: memory.nextUser++,
      nome,
      email,
      senha_hash: hashPassword(senha),
      perfil,
      ativo: true,
      criado_em: now(),
      atualizado_em: now()
    });
  }
  const admin = memory.users.find((u) => u.email === "admin@estoque.local");
  for (const [sku, code, area] of defaultAddressings()) {
    addAddressingMemory({ sku, shelfCode: code, areaCode: area, createAddress: true, usuarioId: admin?.id || null });
  }
  memory.initialized = true;
}

function defaultUsers() {
  return [
    ["Administrador", "admin@estoque.local", "admin123", "Administrador"],
    ["Supervisor", "supervisor@estoque.local", "supervisor123", "Supervisor"],
    ["Operador", "operador@estoque.local", "operador123", "Operador"]
  ];
}

function defaultAddressings() {
  return [
    ["89261", "R01-RK01-L01-A", 1],
    ["48139", "R01-RK01-L01-B", 2],
    ["84915", "R02-RK01-L02-A", 3],
    ["87842", "R03-RK02-L01-C", 4],
    ["90249", "R04-RK01-L03-A", 5]
  ];
}

async function login(res, body) {
  const email = String(body.email || "").trim().toLowerCase();
  const password = String(body.password || "");
  const user = await findUserByEmail(email);
  if (!user || !user.ativo || !verifyPassword(password, user.senha_hash)) {
    return error(res, 401, "Usuário ou senha inválidos.");
  }
  await logAction({ usuarioId: user.id, acao: "Login realizado", detalhes: "Acesso ao sistema" });
  return json(res, { token: createToken(user), user: publicUser(user) });
}

async function findUserByEmail(email) {
  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`SELECT * FROM usuarios WHERE lower(email) = ${email} LIMIT 1`;
    return rows[0] || null;
  }
  return memory.users.find((u) => u.email.toLowerCase() === email) || null;
}

async function getUserById(id) {
  if (!id) return null;
  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`SELECT * FROM usuarios WHERE id = ${Number(id)} LIMIT 1`;
    return rows[0] || null;
  }
  return memory.users.find((u) => u.id === Number(id)) || null;
}

async function dashboard(res) {
  const rows = await listAddressingsData({});
  const localizacoes = await listLocationsData();
  const byArea = groupCount(rows, (row) => `${row.area_linha_separacao_codigo}|${row.area_linha_separacao_nome}`).map((item) => {
    const [codigo, nome] = item.key.split("|");
    return { codigo: Number(codigo), nome, total: item.total };
  });
  const topShelves = groupCount(rows, (row) => row.codigo_endereco)
    .slice(0, 8)
    .map((item) => ({ codigo_endereco: item.key, total: item.total }));
  const byUser = groupCount(rows, (row) => row.usuario_nome || "Sem usuário")
    .slice(0, 8)
    .map((item) => ({ nome: item.key, total: item.total }));
  return json(res, {
    totals: {
      produtosEnderecados: rows.length,
      vinculosSkuEndereco: rows.length,
      localizacoesCriadas: localizacoes.length,
      skusDistintos: new Set(rows.map((row) => row.sku)).size
    },
    byArea,
    latest: rows.slice(0, 10),
    topShelves,
    byUser
  });
}

async function checkAddress(res, code) {
  const parsed = parseShelfCode(code);
  if (!parsed) return error(res, 400, "Código de prateleira inválido. Use o padrão R01-RK01-L01-A.");
  const address = await findLocation(parsed.codigo_endereco);
  return json(res, { exists: Boolean(address), address: address || parsed });
}

async function createAddress(res, shelfCode) {
  const parsed = parseShelfCode(shelfCode);
  if (!parsed) return error(res, 400, "Código de prateleira inválido. Use o padrão R01-RK01-L01-A.");
  return json(res, await ensureLocation(parsed), 201);
}

async function listAddressings(res, query) {
  return json(res, await listAddressingsData(query));
}

async function listAddressingsData(query = {}) {
  if (hasDatabase()) {
    const sql = await getSql();
    let clauses = [];
    let params = [];
    if (query.area) { clauses.push(`e.area_linha_separacao_codigo = $${params.length + 1}`); params.push(Number(query.area)); }
    if (query.rua) { clauses.push(`e.rua = $${params.length + 1}`); params.push(String(query.rua)); }
    if (query.rack) { clauses.push(`e.rack = $${params.length + 1}`); params.push(Number(query.rack)); }
    if (query.user) { clauses.push(`e.usuario_id = $${params.length + 1}`); params.push(Number(query.user)); }
    if (query.sku) { clauses.push(`e.sku = $${params.length + 1}`); params.push(String(query.sku)); }
    if (query.from) { clauses.push(`e.criado_em >= $${params.length + 1}`); params.push(String(query.from)); }
    if (query.to) { clauses.push(`e.criado_em <= $${params.length + 1}`); params.push(`${String(query.to)} 23:59:59`); }
    const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
    return sql.unsafe(`
      SELECT e.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM enderecamentos e
      LEFT JOIN usuarios u ON u.id = e.usuario_id
      ${where}
      ORDER BY e.criado_em DESC, e.id DESC
    `, params);
  }

  return memory.enderecamentos
    .filter((row) => !query.area || row.area_linha_separacao_codigo === Number(query.area))
    .filter((row) => !query.rua || row.rua === query.rua)
    .filter((row) => !query.rack || row.rack === Number(query.rack))
    .filter((row) => !query.user || row.usuario_id === Number(query.user))
    .filter((row) => !query.sku || row.sku === query.sku)
    .sort((a, b) => b.id - a.id)
    .map(withUser);
}

async function createAddressing(res, body, user) {
  const result = await addAddressing({
    sku: body.sku,
    shelfCode: body.shelfCode,
    areaCode: body.areaCode,
    createAddress: body.createAddress !== false,
    usuarioId: user?.id || null
  });
  return result.ok ? json(res, result, result.status) : error(res, result.status, result.message, result);
}

async function addAddressing(payload) {
  if (hasDatabase()) return addAddressingPostgres(payload);
  return addAddressingMemory(payload);
}

async function addAddressingPostgres({ sku, shelfCode, areaCode, createAddress = true, usuarioId = null }) {
  const cleanSku = String(sku || "").trim();
  const parsed = parseShelfCode(shelfCode);
  const area = AREAS.find((item) => item.codigo === Number(areaCode));
  if (!cleanSku) return { ok: false, status: 400, message: "SKU obrigatório." };
  if (!parsed) return { ok: false, status: 400, message: "Código de prateleira inválido. Use o padrão R01-RK01-L01-A." };
  if (!area) return { ok: false, status: 400, message: "Área Linha Separação obrigatória." };
  const existing = await findLocation(parsed.codigo_endereco);
  if (!existing && !createAddress) return { ok: false, status: 404, message: "Endereço não cadastrado." };
  const address = await ensureLocation(parsed);
  const sql = await getSql();
  try {
    const rows = await sql`
      INSERT INTO enderecamentos (
        sku, localizacao_id, rua, rack, linha, letra, codigo_endereco,
        area_linha_separacao_codigo, area_linha_separacao_nome, conferencia_obrigatoria, usuario_id
      )
      VALUES (
        ${cleanSku}, ${address.id}, ${parsed.rua}, ${parsed.rack}, ${parsed.linha}, ${parsed.letra},
        ${parsed.codigo_endereco}, ${area.codigo}, ${area.nome}, 0, ${usuarioId}
      )
      RETURNING *
    `;
    await logAction({ usuarioId, acao: "SKU endereçado", sku: cleanSku, codigoEndereco: parsed.codigo_endereco, detalhes: `Área ${area.codigo} - ${area.nome}` });
    return { ok: true, status: 201, message: "SKU endereçado com sucesso.", record: withUser(await hydrateUser(rows[0])) };
  } catch (err) {
    if (String(err.message).includes("duplicate") || String(err.code) === "23505") {
      return { ok: false, status: 409, message: "Este SKU já está cadastrado neste endereço." };
    }
    throw err;
  }
}

function addAddressingMemory({ sku, shelfCode, areaCode, createAddress = true, usuarioId = null }) {
  const cleanSku = String(sku || "").trim();
  const parsed = parseShelfCode(shelfCode);
  const area = AREAS.find((item) => item.codigo === Number(areaCode));
  if (!cleanSku) return { ok: false, status: 400, message: "SKU obrigatório." };
  if (!parsed) return { ok: false, status: 400, message: "Código de prateleira inválido. Use o padrão R01-RK01-L01-A." };
  if (!area) return { ok: false, status: 400, message: "Área Linha Separação obrigatória." };
  let address = memory.localizacoes.find((loc) => loc.codigo_endereco === parsed.codigo_endereco);
  if (!address && !createAddress) return { ok: false, status: 404, message: "Endereço não cadastrado." };
  address = ensureLocationMemory(parsed);
  if (memory.enderecamentos.some((row) => row.sku === cleanSku && row.codigo_endereco === parsed.codigo_endereco)) {
    return { ok: false, status: 409, message: "Este SKU já está cadastrado neste endereço." };
  }
  const record = {
    id: memory.nextEnd++,
    sku: cleanSku,
    localizacao_id: address.id,
    rua: parsed.rua,
    rack: parsed.rack,
    linha: parsed.linha,
    letra: parsed.letra,
    codigo_endereco: parsed.codigo_endereco,
    area_linha_separacao_codigo: area.codigo,
    area_linha_separacao_nome: area.nome,
    conferencia_obrigatoria: 0,
    usuario_id: usuarioId,
    criado_em: now(),
    atualizado_em: now()
  };
  memory.enderecamentos.unshift(record);
  logActionMemory({ usuarioId, acao: "SKU endereçado", sku: cleanSku, codigoEndereco: parsed.codigo_endereco, detalhes: `Área ${area.codigo} - ${area.nome}` });
  return { ok: true, status: 201, message: "SKU endereçado com sucesso.", record: withUser(record) };
}

async function updateAddressing(res, id, body, user) {
  const sku = String(body.sku || "").trim();
  const parsed = parseShelfCode(body.shelfCode);
  const area = AREAS.find((item) => item.codigo === Number(body.areaCode));
  if (!sku) return error(res, 400, "SKU obrigatório.");
  if (!parsed) return error(res, 400, "Código de prateleira inválido. Use o padrão R01-RK01-L01-A.");
  if (!area) return error(res, 400, "Área Linha Separação obrigatória.");
  const address = await ensureLocation(parsed);

  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`
      UPDATE enderecamentos
      SET sku = ${sku}, localizacao_id = ${address.id}, rua = ${parsed.rua}, rack = ${parsed.rack},
          linha = ${parsed.linha}, letra = ${parsed.letra}, codigo_endereco = ${parsed.codigo_endereco},
          area_linha_separacao_codigo = ${area.codigo}, area_linha_separacao_nome = ${area.nome},
          conferencia_obrigatoria = 0, usuario_id = COALESCE(usuario_id, ${user?.id || null}), atualizado_em = NOW()
      WHERE id = ${id}
      RETURNING *
    `;
    if (!rows.length) return error(res, 404, "Endereçamento não encontrado.");
    await logAction({ usuarioId: user?.id || null, acao: "Endereço alterado", sku, codigoEndereco: parsed.codigo_endereco, detalhes: `Endereçamento ${id} atualizado` });
    return json(res, withUser(await hydrateUser(rows[0])));
  }

  const item = memory.enderecamentos.find((row) => row.id === id);
  if (!item) return error(res, 404, "Endereçamento não encontrado.");
  Object.assign(item, {
    sku,
    localizacao_id: address.id,
    rua: parsed.rua,
    rack: parsed.rack,
    linha: parsed.linha,
    letra: parsed.letra,
    codigo_endereco: parsed.codigo_endereco,
    area_linha_separacao_codigo: area.codigo,
    area_linha_separacao_nome: area.nome,
    usuario_id: item.usuario_id || user?.id || null,
    atualizado_em: now()
  });
  await logAction({ usuarioId: user?.id || null, acao: "Endereço alterado", sku, codigoEndereco: parsed.codigo_endereco, detalhes: `Endereçamento ${id} atualizado` });
  return json(res, withUser(item));
}

async function deleteAddressing(res, id, user) {
  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`DELETE FROM enderecamentos WHERE id = ${id} RETURNING *`;
    if (rows[0]) await logAction({ usuarioId: user?.id || null, acao: "Endereço removido", sku: rows[0].sku, codigoEndereco: rows[0].codigo_endereco, detalhes: `Endereçamento ${id} removido` });
    return json(res, { deleted: Boolean(rows[0]) });
  }
  const index = memory.enderecamentos.findIndex((row) => row.id === id);
  const [removed] = index >= 0 ? memory.enderecamentos.splice(index, 1) : [];
  if (removed) await logAction({ usuarioId: user?.id || null, acao: "Endereço removido", sku: removed.sku, codigoEndereco: removed.codigo_endereco, detalhes: `Endereçamento ${id} removido` });
  return json(res, { deleted: Boolean(removed) });
}

async function searchSku(res, sku, user) {
  const rows = (await listAddressingsData({ sku })).filter((row) => row.sku === sku);
  await logAction({ usuarioId: user?.id || null, acao: "SKU consultado", sku, detalhes: `${rows.length} localização(ões) encontrada(s)` });
  return json(res, rows);
}

async function searchShelf(res, code, user) {
  const parsed = parseShelfCode(code);
  if (!parsed) return error(res, 400, "Código de prateleira inválido. Use o padrão R01-RK01-L01-A.");
  const rows = (await listAddressingsData({})).filter((row) => row.codigo_endereco === parsed.codigo_endereco);
  await logAction({ usuarioId: user?.id || null, acao: "Localização consultada", codigoEndereco: parsed.codigo_endereco, detalhes: `${rows.length} SKU(s) encontrado(s)` });
  return json(res, { address: parsed, totalSkus: rows.length, skus: rows });
}

async function importRows(res, rows, user) {
  const summary = { imported: 0, skipped: 0, errors: [] };
  for (const [index, row] of rows.entries()) {
    const ruaNumber = String(row.rua || "").trim().match(/\d+/)?.[0] || String(row.rua || "").trim();
    const shelfCode = `R${String(Number(ruaNumber)).padStart(2, "0")}-RK${String(Number(String(row.rack || "").trim())).padStart(2, "0")}-L${String(Number(String(row.linha || "").trim())).padStart(2, "0")}-${String(row.letra || "").trim().toUpperCase()}`;
    const result = await addAddressing({
      sku: row.sku,
      shelfCode,
      areaCode: Number(row.areaCode),
      createAddress: true,
      usuarioId: user?.id || null
    });
    if (result.ok) summary.imported += 1;
    else if (result.status === 409) summary.skipped += 1;
    else summary.errors.push({ line: index + 2, message: result.message });
  }
  await logAction({ usuarioId: user?.id || null, acao: "Excel importado", detalhes: `${summary.imported} importado(s), ${summary.skipped} duplicidade(s), ${summary.errors.length} erro(s)` });
  return json(res, summary);
}

async function history(res) {
  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`
      SELECT h.*, u.nome AS usuario_nome, u.email AS usuario_email
      FROM historico h
      LEFT JOIN usuarios u ON u.id = h.usuario_id
      ORDER BY h.criado_em DESC, h.id DESC
      LIMIT 300
    `;
    return json(res, rows);
  }
  return json(res, memory.historico.map(withHistoryUser));
}

async function createHistory(res, body, user) {
  await logAction({
    usuarioId: user?.id || null,
    acao: String(body.acao || "Ação registrada"),
    sku: body.sku || null,
    codigoEndereco: body.codigoEndereco || null,
    detalhes: body.detalhes || null
  });
  return json(res, { ok: true }, 201);
}

async function users(res) {
  if (hasDatabase()) {
    const sql = await getSql();
    return json(res, (await sql`SELECT id, nome, email, perfil, ativo, criado_em, atualizado_em FROM usuarios ORDER BY nome`).map(publicUser));
  }
  return json(res, memory.users.map(publicUser).sort((a, b) => a.nome.localeCompare(b.nome)));
}

async function createUser(res, body) {
  const nome = String(body.nome || "").trim();
  const email = String(body.email || "").trim().toLowerCase();
  const senha = String(body.senha || "");
  const perfil = String(body.perfil || "Operador");
  if (!nome || !email || senha.length < 4) return error(res, 400, "Informe nome, e-mail e senha com pelo menos 4 caracteres.");
  if (hasDatabase()) {
    const sql = await getSql();
    try {
      const rows = await sql`
        INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo)
        VALUES (${nome}, ${email}, ${hashPassword(senha)}, ${perfil}, TRUE)
        RETURNING id, nome, email, perfil, ativo, criado_em, atualizado_em
      `;
      return json(res, publicUser(rows[0]), 201);
    } catch (err) {
      if (String(err.message).includes("duplicate") || String(err.code) === "23505") return error(res, 409, "E-mail já cadastrado.");
      throw err;
    }
  }
  if (memory.users.some((u) => u.email === email)) return error(res, 409, "E-mail já cadastrado.");
  const user = { id: memory.nextUser++, nome, email, senha_hash: hashPassword(senha), perfil, ativo: true, criado_em: now(), atualizado_em: now() };
  memory.users.push(user);
  return json(res, publicUser(user), 201);
}

async function listLocationsData() {
  if (hasDatabase()) {
    const sql = await getSql();
    return sql`SELECT * FROM localizacoes ORDER BY codigo_endereco`;
  }
  return memory.localizacoes;
}

async function findLocation(code) {
  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`SELECT * FROM localizacoes WHERE codigo_endereco = ${code} LIMIT 1`;
    return rows[0] || null;
  }
  return memory.localizacoes.find((loc) => loc.codigo_endereco === code) || null;
}

async function ensureLocation(parsed) {
  if (hasDatabase()) {
    const sql = await getSql();
    const rows = await sql`
      INSERT INTO localizacoes (rua, rack, linha, letra, codigo_endereco)
      VALUES (${parsed.rua}, ${parsed.rack}, ${parsed.linha}, ${parsed.letra}, ${parsed.codigo_endereco})
      ON CONFLICT (codigo_endereco) DO UPDATE SET atualizado_em = localizacoes.atualizado_em
      RETURNING *
    `;
    return rows[0];
  }
  return ensureLocationMemory(parsed);
}

function ensureLocationMemory(parsed) {
  let loc = memory.localizacoes.find((item) => item.codigo_endereco === parsed.codigo_endereco);
  if (loc) return loc;
  loc = { id: memory.nextLoc++, rua: parsed.rua, rack: parsed.rack, linha: parsed.linha, letra: parsed.letra, codigo_endereco: parsed.codigo_endereco, criado_em: now(), atualizado_em: now() };
  memory.localizacoes.push(loc);
  return loc;
}

async function hydrateUser(row) {
  if (!row?.usuario_id) return row;
  const user = await getUserById(row.usuario_id);
  return { ...row, usuario_nome: user?.nome || null, usuario_email: user?.email || null };
}

function withUser(row) {
  const user = memory.users.find((u) => u.id === row.usuario_id);
  return { ...row, usuario_nome: row.usuario_nome ?? user?.nome ?? null, usuario_email: row.usuario_email ?? user?.email ?? null };
}

function withHistoryUser(row) {
  const user = memory.users.find((u) => u.id === row.usuario_id);
  return { ...row, usuario_nome: user?.nome || null, usuario_email: user?.email || null };
}

async function logAction(payload) {
  if (hasDatabase()) {
    const sql = await getSql();
    await sql`
      INSERT INTO historico (usuario_id, acao, sku, codigo_endereco, detalhes)
      VALUES (${payload.usuarioId || null}, ${payload.acao}, ${payload.sku || null}, ${payload.codigoEndereco || null}, ${payload.detalhes || null})
    `;
    return;
  }
  logActionMemory(payload);
}

function logActionMemory({ usuarioId = null, acao, sku = null, codigoEndereco = null, detalhes = null }) {
  memory.historico.unshift({ id: memory.nextHist++, usuario_id: usuarioId, acao, sku, codigo_endereco: codigoEndereco, detalhes, criado_em: now() });
}

async function getUserFromRequest(req) {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const payload = readToken(token);
  return payload ? getUserById(payload.sub) : null;
}

function parseShelfCode(rawCode) {
  const match = String(rawCode || "").trim().toUpperCase().match(/^R(\d+)-RK(\d+)-L(\d+)-([A-Z]+)$/);
  if (!match) return null;
  const ruaNumero = Number(match[1]);
  const rack = Number(match[2]);
  const linha = Number(match[3]);
  const letra = match[4];
  return { rua: `Rua ${pad(ruaNumero)}`, ruaNumero, rack, linha, letra, codigo_endereco: `R${pad(ruaNumero)}-RK${pad(rack)}-L${pad(linha)}-${letra}` };
}

function pad(value) {
  return String(Number(value)).padStart(2, "0");
}

function groupCount(rows, keyFn) {
  const map = new Map();
  rows.forEach((row) => map.set(keyFn(row), (map.get(keyFn(row)) || 0) + 1));
  return [...map.entries()].map(([key, total]) => ({ key, total })).sort((a, b) => b.total - a.total);
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.pbkdf2Sync(String(password), salt, 120000, 32, "sha256").toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password, storedHash) {
  const [salt, hash] = String(storedHash || "").split(":");
  if (!salt || !hash) return false;
  const candidate = hashPassword(password, salt).split(":")[1];
  return crypto.timingSafeEqual(Buffer.from(hash, "hex"), Buffer.from(candidate, "hex"));
}

function createToken(user) {
  const body = Buffer.from(JSON.stringify({ sub: user.id, exp: Date.now() + 1000 * 60 * 60 * 12 })).toString("base64url");
  const signature = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  return `${body}.${signature}`;
}

function readToken(token) {
  const [body, signature] = String(token || "").split(".");
  if (!body || !signature) return null;
  const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  if (expected !== signature) return null;
  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  return payload.exp > Date.now() ? payload : null;
}

function publicUser(user) {
  return { id: user.id, nome: user.nome, email: user.email, perfil: user.perfil, ativo: Boolean(user.ativo), criado_em: user.criado_em, atualizado_em: user.atualizado_em };
}

async function readBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString("utf8");
  return raw ? JSON.parse(raw) : {};
}

function decodeLast(path) {
  return decodeURIComponent(path.split("/").filter(Boolean).at(-1) || "");
}

function now() {
  return new Date().toISOString();
}

function setCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type,Authorization");
}

function json(res, data, status = 200) {
  return res.status(status).json(data);
}

function error(res, status, message, extra = {}) {
  return res.status(status).json({ ...extra, message });
}
