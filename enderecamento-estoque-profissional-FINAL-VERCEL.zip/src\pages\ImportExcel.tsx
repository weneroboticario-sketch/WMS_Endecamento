import { FileSpreadsheet, Upload } from "lucide-react";
import { ChangeEvent, useState } from "react";
import { api } from "../lib/api";
import { parseImportFile } from "../lib/excel";

export function ImportExcel() {
  const [fileName, setFileName] = useState("");
  const [message, setMessage] = useState("");
  const [errors, setErrors] = useState<Array<{ line: number; message: string }>>([]);

  async function importFile(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    if (!file) {
      return;
    }

    setFileName(file.name);
    try {
      const rows = await parseImportFile(file);
      const result = await api.importRows(rows);
      setErrors(result.errors);
      setMessage(`${result.imported} importado(s), ${result.skipped} duplicidade(s) ignorada(s).`);
    } catch (error) {
      setErrors([]);
      setMessage(error instanceof Error ? error.message : "Erro ao importar planilha.");
    }
  }

  return (
    <section className="page">
      <div className="page-header">
        <div>
          <span className="eyebrow">Importação opcional</span>
          <h1>Importar Excel</h1>
        </div>
      </div>

      <label className="upload-box">
        <FileSpreadsheet size={36} />
        <strong>{fileName || "Selecionar planilha .xlsx"}</strong>
        <span>Aba LinhaSeparacao no mesmo modelo da exportação</span>
        <input accept=".xlsx,.xls" onChange={importFile} type="file" />
      </label>

      {message && <div className="system-message ok">{message}</div>}

      {errors.length > 0 && (
        <section className="panel">
          <div className="panel-title">
            <Upload size={18} />
            <h2>Registros com erro</h2>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Linha</th>
                  <th>Erro</th>
                </tr>
              </thead>
              <tbody>
                {errors.map((error) => (
                  <tr key={`${error.line}-${error.message}`}>
                    <td>{error.line}</td>
                    <td>{error.message}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </section>
  );
}
